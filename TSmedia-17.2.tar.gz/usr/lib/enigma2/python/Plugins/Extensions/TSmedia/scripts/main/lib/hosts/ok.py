# -*- coding: utf-8 -*-
# ------------------------------------------------------------
##coded by aime_jeux-------------------------------------------
from iTools import CBaseAddonClass,printE,printD ## you can import any iTools functions
self=CBaseAddonClass()## you can use this class functions anywhere in your code as self.addDir,self.getPage...
# 


def postData(url):
    import re
    
    URLIST = []
   
    htmldata=self.getPage(url)
    
    htmldata=str(htmldata).replace('\\', '').replace('&quot;','"').replace(';','').replace('u0026','&')
    coucou = re.findall(r'\{"name":"(.*?)","url":"(.*?)"', htmldata, re.DOTALL)
    if coucou:
        for a,b in coucou:
            w= ( 'Ok *__* '+a,b)
            URLIST.append(w)
    else:
        w = ('Ooops_Error','http//error')
        URLIST.append(w)
    return URLIST
#kl = 'https://ok.ru/videoembed/1049441405449'
#AA = postData(kl)
#print AA
def get_video_url(url):
   return postData(url)





if __name__=='__main__':
     
     url0='https://ok.ru/videoembed/1049441405449'
     url1='https://ok.ru/videoembed/1049441405449'
     url2='https://ok.ru/videoembed/1049441405449'
     url3='https://ok.ru/videoembed/1049441405449'
     url4='https://ok.ru/videoembed/1049441405449'
     url5='https://gdriveplayer.to/embed2.php?link=pvXRDqJdY7788GeICfGwvAXzqMwzaHkUELrslGiQQ52TEpgPTNgVuBo9w6leIs6CXS8hV2%252B8sfrrhZi2Nks8W4AJrY1OnbIns8R1H40l%252BGIk5uBaphpU7cADj0Y4CSPT58YL9XrV9pPkTAR70W2GvlcfwmTwc83fKWWtZTp%252Bh81U9IZ5MtvZV0RZ2WpicPkAhkd4kITo%252FokO3tJvvCRQUf'
     url6='https://gdriveplayer.to/embed2.php?link=pvXRDqJdY7788GeICfGwvAXzqMwzaHkUELrslGiQQ52TEpgPTNgVuBo9w6leIs6CXS8hV2%252B8sfrrhZi2Nks8W4AJrY1OnbIns8R1H40l%252BGIk5uBaphpU7cADj0Y4CSPT58YL9XrV9pPkTAR70W2GvlcfwmTwc83fKWWtZTp%252Bh81U9IZ5MtvZV0RZ2WpicPkAhkd4kITo%252FokO3tJvvCRQUf'
     url7='https://vidbem.com/embed-m2ly7rwq9wnu.html?Key=VDC8F8nZJ3q_5xEGohol2Q&Expires=1602257990'
     print get_video_url(url0)