# -*- coding: utf8 -*-
Agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; …) Gecko/20100101 Firefox/65.0'}
UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20100101 Firefox/70.0'
import requests,re
Sgn = requests.Session()
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
def get_token(site_key, co, loc):
    sa = ''
    cb = '365ae0il5lwn'
    headers1 = {'user-agent':UA,
               'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
               'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
               'Referer':loc
                }
    url1 = 'https://www.google.com/recaptcha/api.js'
    s = requests.session()
    req = s.get(url1, headers=headers1,verify=False)
    data = req.text
    aresult = re.findall("releases\/(.*?)\/", data)
    if aresult:
        v = aresult[0]
    else:
        return False, False
    url2 = "https://www.google.com/recaptcha/api2/anchor?ar=1&k=" + site_key + "&co=" + co + "&hl=ro&v=" + v + "&size=invisible&cb=" + cb
    req = s.get(url2)
    data = req.text
    data = data.replace('\x22', '')
    aresult = re.findall("recaptcha-token.*?=(.*?)>", data)
    if aresult:
        c = aresult[0]
    else:
        return False, False
    url3 = "https://www.google.com/recaptcha/api2/reload?k=" + site_key
    post_data = {'v':v, 'reason':'q', 'k':site_key, 'c':c, 'sa':sa, 'co':co}
    headers2 = {'user-agent':UA,
               'Accept':'*/*',
               'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
               'Referer':url2
                }
    req_url3 = s.post(url3, data=post_data, headers=headers2,verify=False)
    data = req_url3.text
    aresult = re.findall("resp\",\"(.*?)\"", data)
    if aresult:
        token  = aresult[0]
        return True, token
    return False, False
def get_video_url(uri):
    url = uri
    api_call = ''
    Mlist= []
    key = "6LcOeuUUAAAAANS5Gb3oKwWkBjOdMXxqbj_2cPCy"
    co = "aHR0cHM6Ly9hYmN2aWRlby5jYzo0NDM."
    loc = "https://abcvideo.cc"
    sUrlPlayer = "https://abcvideo.cc/dl"
    urlcode = url.replace('embed-', '')
    urlcode = urlcode.replace('.html', '')
    code = urlcode.split('/')[-1]
    headers1 = {'user-agent':UA,
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
                }
    headers2 = {'user-agent':UA,
                'Accept':'*/*',
                'Content-Type':'text/plain; charset=UTF-8',
                'Referer':url
                }
    s = requests.session()
    s.get(url, headers=headers1,verify=False)
    bvalid, token = get_token(key, co, loc)
    if bvalid:
        url2 = sUrlPlayer + '?op=video_src&file_code=' + code + '&g-recaptcha-response=' + token
        req = s.get(url2, headers=headers2,verify=False)
        response = str(req.content)
        print "+++++++++++++++++++++++++++++++",response
        regx = '"(https.+?)"'
        aResult = re.findall(regx, response)
        if aResult:
            api_call = aResult[0]
            req = s.get(api_call, headers=headers2,verify=False)
            response = str(req.content)
            regx = 'PROGRAM.*?BANDWIDTH.*?RESOLUTION=(\d+x\d+).*?(https.*?m3u8)'
            aMatches = re.compile(regx, re.IGNORECASE|re.S).findall(response)
            print "--------------------------------------------------",response
            if aMatches:
                Mlist.append(('Cool_abcvideo ['+str(aMatches[0][0])+']',aMatches[0][1]))
            else:
                Mlist.append(('Cool_abcvideo [M3u8]',api_call))
        else:Mlist.append(('Ooops_abcvideo','http://Error'))
    else:Mlist.append(('Ooops_abcvideo','http://Error'))
    return Mlist 
if __name__=='__main__':
    url0='https://abcvideo.cc/embed-hd4i0mdcymvu.html'
    print get_video_url(url0)