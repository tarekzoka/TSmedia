import re
hdr={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Accept-Encoding': 'gzip, deflate',
     'Connection': 'keep-alive',
     'Upgrade-Insecure-Requests': '1',
     'Cache-Control': 'max-age=0'}
head = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
        'Accept': '*/*',
        'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
        'Accept-Encoding': 'gzip, deflate',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://eg.arabseed.ink/%d9%81%d9%8a%d9%84%d9%85-always-and-forever-2020-%d9%85%d8%aa%d8%b1%d8%ac%d9%85/watch/'}
def get_arabseed_Servers(self,url,Host):
    url = url
    hdr.update({'Host': Host})
    def get_arabseed(uri):
        _r = self.getPage(uri)
        _xx = '''<source src="(.+?)"'''
        source = self.getMM(_r,_xx)
        if source:
            return source[0]
        else:
            return ''
    if url.endswith('/'):url=url+"watch/"
    else:url = url+"/watch/"
    MyList = []
    _r = self.getPage(url,addParams=hdr)
    tmx = '<i class="fal fa-play"></i>.+?<span>(.+?)</span>.+?<iframe.+?src="(.+?)".+?></iframe>'
    tmx1 = '''<i class="fal fa-play"></i> <span>(.+?)</span>.+?<IFRAME SRC="(.+?)".+?></IFRAME>'''
    _server = re.findall(tmx,_r)
    _server1 = re.findall(tmx1,_r)
    print "_server =",_server
    print "_server1 =",_server1
    if _server:
        for x,y in _server:
            if y.startswith('//'):y="https:"+y
            x = x.decode('utf-8')
            w = (x,y)
            MyList.append(w)
    if _server1:
        for x,y in _server1:
            if y.startswith('//'):y="https:"+y
            x = x.decode('utf-8')
            w = (x,y)
            MyList.append(w)
    return MyList
