# -*- coding: utf8 -*-
import urllib,urllib2,re,sys,os,ast,random,warnings,requests
from iTools import CBaseAddonClass,printD,printE
from hosts.tstls import * 
###from tslib import requests
from tslib.requests.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
base_url="https://f15.arabseed.ink"
hdr_={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; E6633 Build/32.4.A.1.54)',
     'Accept-Encoding': 'gzip'}
os_platform=sys.platform
def get_request(url,headers,params,method):
    try:
        if method=='POST':
            r = requests.post(url, headers=headers,json=params,verify=False)
        else:
            r = requests.get(url, headers=headers,verify=False)
    except:
        printE()
        pass
    return r.content,r.status_code,r.url
##########################################
def filterTitle(self,title):
    year=''
    try:
        title=self.removeunicode(title)
        #print "title1",title
        try:year =  re.findall(r'\d+', title)[0]
        except:year=''
        #print "year",year
        title=title.replace(year,'').strip()
        title=title.replace('مترجم','').strip()
        title=title.replace('فيلم','').strip()
        #print "title2",title
        return title,year
    except:
        return title,year
def getMeta(self,title,show='movie',season=0,episode=0):
    year=''
    season=0
    episode=0
    metaData={}
    try:
        ####title,year parsing code,modify according to your data
        if self.allUnicode(title):
            if "مسلسل" in title:
                season=self.getSeason(title)
                printD("season1234",season) 
                episode=self.getDigits(title)
                title=title.decode("utf-8")
                title=title.split(u"الموسم")[0]
                title=title.split(u"الحلقة")[0].replace(u"مسلسل",'')
                title=title.strip()
                year=''
                show='tv'
            else:
                year=self.getDigits(title)
                title=self.removeDigits(title)
                title=title.replace("فيلم",'').strip()
                show='movie'
        else:
            if "مسلسل" in title:
                season=self.getSeason(title)
                episode=self.getDigits(title)
                title=self.removeunicode(title)
                title=self.removeDigits(title)
                year=''
                show='tv'
            else:
                title=self.removeunicode(title)
                year=self.getDigits(title)
                title=self.removeDigits(title)
                show='movie'
        ###############
        metaData={"name":title,'year':str(year),'show':show,'season':season,"episode":episode}
        return metaData 
    except:
        pass
        #printE()
        return metaData
class arabseed(CBaseAddonClass):
    def __init__(self,params={}):
        CBaseAddonClass.__init__(self,{'cookie':'arabseed.cookie'})
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = base_url
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        self.cacheLinks  = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
    def showmenu(self):
        self.addDir('Search ',base_url+'/search?s=',103,'img/search.png','',1,searchall=__file__)
        self.addDir('افلام اجنبيه',base_url+'/category/foreign-movies4/',100,'img/1.png','',1)
        self.addDir('مسلسلات اجنبيه',base_url+'/category/foreign-series/',200,'img/2.png','',1)
        self.addDir('افلام عربيه',base_url+'/category/مسلسلات-عربي/',100,'img/3.png','',1)
        self.addDir('مسلسلات رمضان 2023',base_url+'/category/ramadan-series-2023/',200,'img/ramadan2023.png','',1)
        self.addDir('مسلسلات رمضان 2022',base_url+'/category/مسلسلات-رمضان-2022/',200,'img/ramadan2022.png','',1)
        self.addDir('مسلسلات رمضان 2021',base_url+'/category/مسلسلات-رمضان-2021/',200,'img/ramadan2021.png','',1)
        self.addDir('مسلسلات رمضان 2020',base_url+'/category/مسلسلات-رمضان-2020-hd/',200,'img/14.png','',1)
        self.addDir('مسلسلات رمضان 2019',base_url+'/category/مسلسلات-رمضان-2019/',200,'img/14.png','',1)
        self.addDir('مسلسلات-عربيه',base_url+'/category/مسلسلات-عربي/',200,'img/3.png','',1)
       
        self.addDir('افلام هندى',base_url+'/category/indian-movies/',100,'img/6.png','',1)
        self.addDir('افلام كلاسيكية',base_url+'/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%83%d9%84%d8%a7%d8%b3%d9%8a%d9%83%d9%8a%d9%87/',100,'img/7.png','',1)
        self.addDir('افلام انيميشن',base_url+'/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%8A%D9%85%D9%8A%D8%B4%D9%86/',100,'img/8.png','',1)
        self.addDir('مسرحيات عربية',base_url+'/category/مسرحيات-عربي/',100,'img/4.png','',1)
        self.addDir('مسلسلات-كرتون',base_url+'/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%83%D8%B1%D8%AA%D9%88%D9%86/',200,'img/16.png','',1)
        self.addDir('افلام-مدبلجة',base_url+'/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%85%D8%AF%D8%A8%D9%84%D8%AC%D8%A9/',100,'img/18.png','',1)
        
        self.addDir('افلام-اسيوية',base_url+'/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%b3%d9%8a%d9%88%d9%8a%d8%a9/',100,'img/21.png','',1)
        self.addDir('افلام-تركية',base_url+'/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%aa%d8%b1%d9%83%d9%8a%d8%a9/',100,'img/22.png','',1)
        self.addDir('مسلسلات تركية',base_url+'/category/turkish-series-1/',200,'img/23.png','',1)
        self.addDir('مسلسلات-كوريه',base_url+'/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%83%d9%88%d8%b1%d9%8a%d9%87/',200,'img/24.png','',1)
        self.addDir('مسلسلات-مدبلجة',base_url+'/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%85%d8%af%d8%a8%d9%84%d8%ac%d8%a9/',200,'img/25.png','',1)
        self.addDir('مسلسلات-هندية',base_url+'/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%87%d9%86%d8%af%d9%8a%d8%a9/',200,'img/26.png','',1)
        self.addDir('رياضه',base_url+'/category/%d8%b1%d9%8a%d8%a7%d8%b6%d9%87/',100,'img/20.png','',1)
        self.addDir('مصارعه',base_url+'/category/wwe-shows/',100,'img/27.png','',1)
    ###################################search
    def search_103(self,name,sterm,page):
        surl=base_url+'/find/?find=%s'%sterm
        if page>1:
            url_page=base_url+'/find/?find=%s&offset=%s'%(sterm,str(page))
        else:
            url_page=surl
        print "url_page",url_page
        #data=self.getcfPage(url_page)
        data,st_code,_hst=get_request(url_page,hdr,'','GET')
        if data is None:
            return
        blocks=data.split('class="PlayButton"')
        print "blocks",len(blocks)
        i=0
        blocks.pop(0)
        for block in blocks:
            regx='''href="(.*?)"'''                   
            href=self.getSM(block,regx)
            regx='''data-src="(.*?)"'''                   
            image=self.getSM(block,regx)
            regx='''<h4>(.*?)</h4>'''
            title=self.getSM(block,regx)
            title1=title
            #metaData['poster']=image
            if "مسلسل" in title:
                show='tv'
                mode=201
            else:
                show='movie'
                mode=1
            metaData= getMeta(self,title,show=show)
            #printD("metaData1234",metaData)
            regx='''class="RateNumber">(.*?)</span>'''
            rating=self.getSM(block,regx)
            if rating!='':title=title1+" "+"("+rating+")"
            else:title=title1
            title=self.colorize(title,"green")
            try:self.addDir(title,href,mode,image,name,1,True,metaData=metaData)
            except:pass
    ######################            except:pass
        if len(blocks)>40:
            self.addDir("next page",sterm,103,'img/next.png','',str(page+1),dialog='nsearch')
    def getmovies_100(self,name,url,page,metaData):#mode == 100
        if page>1:
            url_page=url+"?page="+str(page)
        else:
            url_page=url
        #data=self.getPage(url_page)
        data=requests.get(url_page,headers=hdr,verify=False).content
        if data is None:
            return
        #blocks=self.getBlocks(data,'class="PlayButton"')
        blocks=data.split('class="PlayButton"')
        blocks.pop(0)
        print "blocks",len(blocks)
        for block in blocks:
            if 'alt="اعلان">' in block:pass
            else:
                regx='''href="(.*?)"'''                   
                #href=self.getSM(block,regx)
                href=re.findall(regx,block, re.M|re.I)[0]
                regx='''data-src="(.*?)"'''                   
                image=self.getSM(block,regx)
                #print '-------------------',image
                regx='''<h4>(.*?)</h4>'''
                title=self.getSM(block,regx)
                title1=title
                title=title.replace("&#8217;","'")
                title=title.replace("&#8211;","-")
                #######Info metadata##############
                info=''
                regx='''RateNumber">(.*?)</span>'''
                rating=self.getSM(block,regx)
                metaData['rating']=rating
                regx='''Ribbon">(.*?)</div>'''
                quality=self.getSM(block,regx)
                metaData['quality']=quality
                info=quality+" "+rating
                title=title.replace("#039;","")
                info=title+"("+info+")"
                title=self.colorize(info)
                #metaData=getMeta(self,title)
                #regx='''class="RateNumber">(.*?)</span>'''
                #rating=self.getSM(block,regx)
                #if rating!='':title=title1+" "+"("+rating+")"
                #else:title=title1
                fTitle,year=filterTitle(self,title)
                #print "FTITLE:",year
                metaData={"name":fTitle,"year":year,"show":'movie'}
                title=self.colorize(title,"green")
                #self.addDir(title,href,1,image,name,1,True,metaData=metaData)
                self.addDir(title,href,1,image,name,1,True,metaData=metaData)
        if len(blocks)>19:
            self.addDir("next page",url,100,'img/next.png','',str(page+1))
    ###############################################series
    def getseries_200(self,name,url,page,metaData):#mode==200
        import urllib2, ssl
        if page>1:
            url_page=url+"?page="+str(page)
        else:
            url_page=url  
        #data=self.getPage(url_page)
        ###data=requests.get(url_page,headers=hdr,verify=False,allow_redirects=True).content
        #,headers,params,method
        data,st_code,_hst=get_request(url_page,hdr,'','GET')
        print "STATUS CODExxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",st_code
        
        blocks=data.split('<div class="PlayButton">')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='''href="(.*?)"'''                   
            href=self.getSM(block,regx)
            #regx='''data-image="(.*?)"'''                   
            #image=self.getSM(block,regx)
            regx='''data-src="(.*?)"''' 
            image=self.getSM(block,regx)
            regx='''<h4>(.*?)</h4>'''                   
            title=self.getSM(block,regx)
            #metaData= getMeta(self,title,show='tv')#newMeta(self,title,show='tv')
            #print "metadata2123",metaData
            #regx='''<span class="RateNumber">(.*?)</span>'''                   
            #rating=self.getSM(block,regx)
            #if rating!='':
            #    title=title+"("+rating+")"
            regx='''<p>(.*?)</p>'''
            #desc=self.getSM(block,regx)
            metaData['poster']=image
            title=self.colorize(title,"green")
            if 'كامل' in title:
                continue
            title=title.replace("&#8217"," ")
            try:self.addDir(title,href,201,image,name,1,True,metaData=metaData)
            except:pass
        if len(blocks)>22:
            self.addDir("next page",url,200,'img/next.png','',str(page+1))
    ###############################################series
    def getepisode_201(self,name,url,image,page,metaData):#mode==201
        ######################
        episode=metaData.get("episode",0)
        metaData=self.updateMeta(metaData)      
        episode=metaData.get("episode",0)
        season=metaData.get("season",1)
        seID="S%sE%s"%(str(season),str(episode))
        epiMeta=metaData.get(seID,{})
        ###########################
        self.addDir(name,url,1,image,name,1,metaData=epiMeta,style='servers')
        data=requests.get(url,headers=hdr,verify=False).content
        regx='class="SeasonsListHolder">(.*?)class="ContainerEpisodesList">'
        data_=self.getSM(data,regx)
        ###*******************************************
        blocks=data_.split('data-id')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='="(.*?)"'
            data_id=self.getSM(block,regx)
            regx='data-season="(.*?)"'
            season_id=self.getSM(block,regx)
            regx='<span>(.*?)</span>'
            season_num=self.getSM(block,regx)
            #print "SEASON:",season_id
            metaData['show_url']=url
            metaData['season']=season_id
            metaData['post_id']=data_id
            self.addDir('الموسم '+season_num,'href',202,image,name,1,maintitle=True,metaData=metaData)

        ###self.addDir("حلقات اخرى",url,202,image,name,1,metaData=metaData,style='servers') 
    def getepisodes_202(self,name,url,image,page,metaData):#mode==202
        Post_HDR={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                  #'Accept': 'text/html, */*; q=0.01',
                  #'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                  #'X-Requested-With': 'XMLHttpRequest',
                  'Referer':url,
                  'Accept-Encoding': 'gzip, deflate, br'}
                  
        params='season=%s&post_id=%s'%(metaData['season'],metaData['post_id'])
        data=requests.post(base_url+'/wp-content/themes/Elshaikh2021/Ajaxat/Single/Episodes.php',data=params,headers=Post_HDR,verify=False).content
        #data=requests.get(url,headers=hdr,verify=False).content
        blocks=data.split('<a  ')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='href="(.*?)"'
            href=self.getSM(block,regx)
            regx='<em>(.*?)</em>'
            episode=self.getSM(block,regx)
            self.addDir(episode+' الحلقة',href,1,image,name,1,metaData=metaData,style='servers')
######host resolving
    def MyClean(self,txt):
        txt = txt.replace('مشاهدة وتحميل فيلم',' ')
        txt = txt.replace('مشاهدة اون لاين وتحميل مباشر عبر موقع عرب سيد',' ')
        txt = txt.replace('Arabseed',' ')
        # txt = txt.replace('','')
        # txt = txt.replace('','')
        return txt
    def getservers(self,name,url,image,metaData):
        Sess=requests.Session()
        HDR_={'User-Agent': random.choice(USER_AGENTS),
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
              'Upgrade-Insecure-Requests':'1',
              #'Sec-Fetch-Dest':'document',
              'Sec-Fetch-Mode':'navigate',
              #'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
              'Referer': base_url,#}
              'Accept-Encoding':'gzip, deflate'}

        '''printD("input-meta",metaData)
        if metaData.get("imdb_id",'')=="":
            metaData=self.updateMeta(metaData)
            printD("output-meta",metaData)'''
        ###data=self.getPage(url)
        data=requests.get(url,headers=HDR_,verify=False).content
        
        regx='class="WatchButtons">(.*?)class="watchBTn">'
        data_=self.getSM(data,regx)
       
        regx='<a href="(.*?)"'
        prev_urls=self.getSM(data_,regx)
        
        #print "PREVIEW URLSxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",prev_urls
        data_=Sess.get(prev_urls,headers=HDR_,verify=False,allow_redirects=True).content
        
        regx='class="WatcherArea">(.*?)</ul>'#</li>\n</ul>'
        data=self.getSM(data_,regx)
        #print data
        #regx='class="WatcherArea">(.*?)</div>'
        #srv_data=self.getSM(data,regx)
        '''blocks_=data_.split('<h3>')
        blocks_.pop(0)'''
        ###blocks=data_.split('<li data')
        
        qlt_lst=[]
        '''for block_ in blocks_:
            regx='مشاهدة(.*?)</h3>'
            qlt=self.getSM(block_,regx)
            print "Qualityxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",qlt
            metaData['qlt']=self.getSM(block_,regx)'''
        blocks=data.split('class="fal fa-play">')
        blocks.pop(-1)
        for block in blocks:
                 
                 #regx='مشاهدة(.*?)</h3>'
                 #qlt=self.getSM(block,regx)
                 regx='<span>(.*?)</span>'
                 server=self.getSM(block,regx)
                 
                 #server=server.encode('utf-8')
                 regx='data-link="(.*?)"'
                 server_url=self.getSM(block,regx)
                 #print "SERVERxxxxxxxxxxxxxxxxxxxxx:"+server+':::::'+server_url
                 if "reviewtech" in server_url:
                     server_data=requests.get(server_url,headers=HDR_,verify=False).content
                     regx='source src="(.*?)"'
                     server_url=self.getSM(server_data,regx)
                     if 'seeeed' in server_url:
                         self.addDir(name+' ['+server+']',server_url,0,image,name,1,metaData=metaData,style='servers')
                 if not 'seeeed' in server_url:
                     self.addDir(server,server_url,2,image,name,1,metaData=metaData,style='servers')
    def getservers_1(self,name,url,img,metaData):
        try:
            printD("input-meta",metaData)
            if metaData.get("imdb_id",'')=="":
                metaData=self.updateMeta(metaData)
                printD("output-meta",metaData)
            if url.endswith('/'):url=url+"watch/"
            else:url = url+"/watch/"
            data=self.getPage(url)
            regx='MyAjaxURL = "(.*?)"'
            Ajax_Url=self.getSM(data,regx)
            blocks=data.split('<li data-p')
            i=0
            blocks.pop(0)
            for block in blocks:
                regx='class="fal fa-play"></i>\n<span>(.*?)</span>'                   
                server=self.getSM(block,regx)
                regx='data-server="(.*?)"'
                server_dt =self.getSM(block,regx)
                regx='data-qu="(.*?)"'
                server_qlt=self.getSM(block,regx)
                regx='ost="(.*?)"'
                post_id=self.getSM(block,regx)
                POST_HDR={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
                          'Accept': '*/*',
                          'Accept-Language':'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                          'Accept-Encoding': 'gzip, deflate'}
                post_data='post_id='+post_id+'&server='+server_dt+'&qu='+server_qlt
                srvs_data=requests.post(Ajax_Url+'Single/Server.php',data=post_data,headers=POST_HDR,verify=False).content
                if 'IFRAME SRC="' in srvs_data:
                    regx='IFRAME SRC="(.*?)"'
                    server_url=self.getSM(srvs_data,regx)
                elif 'iframe src="' in srvs_data:
                    regx='<iframe src="(.*?)"'
                    server_url=self.getSM(srvs_data,regx)
                if 'seeeed' in server_url:
                    print "SEED!!!!!!!!!!!!!!!!!!!!!!!!!"
                    self.addDir(name+' ['+server+']',server_url,0,img,name,1,metaData=metaData,style='servers')
                else:
                    self.addDir(name+' _'+server_qlt+' ['+server+']', server_url, 2,img,metaData=metaData,style='servers')    
        except:
            printE()
            printD()
            pass
                                     
            
        
            #print "SERVER Namexxxxxxxxxxxxxxxxxxxxxxx:",server
            #print "Server URLxxxxxxxxxxxxxxxxxxxxxxxx:",server_url
            #if "m.arabseed.me" in server_url:
            #    server_url=server_url.replace('m.arabseed.me','m.seeeed.xyz')
        
        
        return
    def getservers_2(self,name,url,img,metaData):#Mode == 3
        metaData=self.updateMeta(metaData)
        if 'seeeed' in url :
            data=self.getPage(url)
            regx='''<source src="(.+?)"'''
            hrefs=re.findall(regx,data, re.M|re.I)
            for href in hrefs:
                print '***************************href__*****************',href
                self.addDir('arabseed'+"-"+name,href,0,img,name,1,metaData=metaData,style='servers')
            
            
    def resolve_host(self,name,url):
        if os_platform=="win32" or os_platform=="win64":
            u_referer = ' :http-referrer="'+url+'"'
        else:
            u_referer = '#Referer='+url
            
        
        
        if "upstream" in url:
            stream_url=get_upstream_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "voe.sx" in url:
            stream_url = get_voesx_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "vtube" in url:
            stream_url=get_vtube_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "dood" in url:
            stream_url=get_doodstream_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "userload" in url:
            stream_url=get_userload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "tubeload" in url:
            stream_url=get_tubeload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)    
        elif "upvideo" in url:
            stream_url=get_upvideo_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "uptostream" in url:
            stream_url=get_uptoboxstream_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "vidmoly" in url or "filemoon" in url:
            stream_url=get_auto_detect_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        
        else:
            if not "https" in url and "//" in url:
                url="https:"+url    
                
            self.resolvehost(name,url)
            
    def run(self,params={}):
        url=None
        name=None
        mode=None
        page=1
        name=params.get("name",'')
        url=params.get("url",'')
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",'')
        section=params.get("section",'')
        page=int(params.get("page",1))
        extra=params.get("extra",{})
        desc=params.get("desc",'') 
        show=params.get("show",'')
        metaData=params.get("metaData",{})
        if mode==None:
            self.showmenu()     
        elif mode==1:
            self.getservers(name,url,image,metaData)
            #self.getservers_1(name,url,image,metaData)
        elif mode==2:
            self.resolve_host(name,url)
        elif mode==3:
            self.getservers_2(name,url,image,metaData)
        elif mode==103:
            sterm = self.getsearchtext()
            self.search_103("Search",sterm,page)
        elif mode==100:
            self.getmovies_100(name,url,page,metaData)
        ###series
        elif mode==200:
            self.getseries_200(name,url,page,metaData)
        elif mode==201:
            self.getepisode_201(name,url,image,page,metaData)
        elif mode==202:
            self.getepisodes_202(name,url,image,page,metaData)
        return self.endDir()
def start(params={}):
    addon=arabseed(params)
    addon._iniAddon()
    return addon.run(params)



