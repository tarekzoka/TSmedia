#!/usr/bin/python -u
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,ast,warnings,json
from base64 import b64encode,b64decode
from iTools import CBaseAddonClass,printD,printE
from hosts.tstls import *
from tslib import requests
#from requests.packages.urllib3.exceptions import InsecureRequestWarning
#requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from tslib.requests.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
base_url="https://laroza.vip"
os_platform=sys.platform
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
cfg_path = os.path.join(__location__, 'TSmedia.srt')
zip_fname = os.path.join(__location__,'TSmediaSub.zip')
SRCH_HDR={'User-Agent':'Mozilla/5.0 (PlayStation 4 4.71) AppleWebKit/601.2 (KHTML, like Gecko)',
          'Referer':'https://w.cimalek.io/?s=prison'}

def filterTitle(self,title):
    year=''
    try:
        title=self.removeunicode(title)
        print "title1",title
        try:year =  re.findall(r'\d+', title)[0]
        except:year=''
        print "year",year
        title=title.replace(year,'').strip()
        title=title.replace('مترجم','').strip()
        title=title.replace('مشاهدة فيلم','').strip()
        title=title.replace('فيلم','').strip()
        print "title2",title
        return title,year
    except:
        return title,year
def getEpisode(self,title_):
    title_=self.removeunicode(title_)
    title_=title_.replace('(','')
    title_=title_.replace(')','')
    match = re.search(
        r'''(?ix)                 # Ignore case (i), and use verbose regex (x)
        (?:                       # non-grouping pattern
          الحلقة|^           # e or x or episode or start of a line
          )                       # end non-grouping pattern 
        \s*                       # 0-or-more whitespaces
        (\d{2})                   # exactly 2 digits
        ''', title_)
    if match:
        return match.group(1)    
##########################################
class laroza(CBaseAddonClass):
    def __init__(self,cParams={}):
        CBaseAddonClass.__init__(self,{'cookie':'laroza.cookie'})
        self.cParams=cParams
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = base_url
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        self.cacheLinks  = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
    def showmenu(self):
        self.addDir('Search ','search',103,'img/0.png','',1,searchall=__file__)
        self.addDir('افلام عربي',base_url+'/category.php?cat=arabic-movies10',100,'img/0.png','',1)
        self.addDir('افلام اجنبية',base_url+'/category.php?cat=english-movies2',100,'img/0.png','',1)
        self.addDir('مسلسلات اجنبيه',base_url+'/category.php?cat=english-series3',200,'img/0.png','',1)
        self.addDir('مسلسلات عربية',base_url+'/category.php?cat=arabic-series22',200,'img/0.png','',1)
        self.addDir('مسلسلات تركية',base_url+'/category.php?cat=turkish-3isk-seriess21',200,'img/0.png','',1)
        self.addDir('مسلسلات هندية',base_url+'/category.php?cat=4indian-series',200,'img/0.png','',1)
        self.addDir('مسلسلات رمضان 2023',base_url+'/category.php?cat=ramadan-2023',200,'img/0.png','',1)
        self.addDir('مسلسلات رمضان 2022',base_url+'/category.php?cat=21ramadan-2022',200,'img/0.png','',1)
        self.addDir('مسلسلات رمضان 2021',base_url+'/category.php?cat=16ramadan-2021',200,'img/0.png','',1)
        self.addDir('مسلسلات رمضان 2020',base_url+'/category.php?cat=2ramadan-2020',200,'img/0.png','',1)
        
        
      
        
    ###################################
   
    def search(self,name,sterm,page,metaData):
        if page>1:
            page_url=base_url+'/search.php?keywords=%s&page=%s'%(sterm,str(page))
            
        else:
            page_url=base_url+'/search.php?keywords=%s'%sterm
        data=self.getPage(page_url)
        blocks=data.split('class="col-xs-6 col-sm-4 col-md-3"')
        blocks.pop(0)
        print "blocks",len(blocks)
        for block in blocks:
            regx='<a href="(.*?)" title'
            href=self.getSM(block,regx)
            regx='alt="(.*?)"'
            title=self.getSM(block,regx)
            regx='data-echo="(.*?)"'
            image=self.getSM(block,regx)
            title=title.replace("&#8217","-")
            title=title.replace("&#039","'")
            title=title.replace('&#8211;','-')
            title=title.replace('&#038;','&')
            title=title.replace("&#8230","...")
            title=title.replace(';','')
            #regx='''<span class="quality">(.*?)</span>'''
            #fTitle,year_=filterTitle(self,title)
            
            if "مسلسل" in title:
                metaData={"name":title,"show":"tv"}
                self.addDir(title,href,201,image,name,1,maintitle=True,metaData=metaData)
            else:
                metaData={"name":title,"show":"movie"}
                self.addDir(title,href.replace('/video','/play'),1,image,name,1,maintitle=True,metaData=metaData)
        if len(blocks)>15:
            self.addDir("next page",page_url,200,'img/next.png','',str(page+1))
        
        

        
    def getmovies(self,name,url,page,metaData):
        if page>1:
            page_url=url+"&page="+str(page)+"&order=DESC"
        else:
            page_url=url

        data=self.getPage(page_url)
        blocks=data.split('class="col-xs-6 col-sm-4 col-md-3"')
        blocks.pop(0)
        print "blocks",len(blocks)
        for block in blocks:
            regx='<a href="(.*?)" title'
            href=self.getSM(block,regx)
            regx='alt="(.*?)"'
            title=self.getSM(block,regx)
            regx='data-echo="(.*?)"'
            image=self.getSM(block,regx)
            title=title.replace("&#8217","-")
            title=title.replace("&#039","'")
            title=title.replace('&#8211;','-')
            title=title.replace('&#038;','&')
            title=title.replace("&#8230","...")
            title=title.replace(';','')
            metaData={"name":title,"show":"movie"}
            self.addDir(title,href,201,image,name,1,maintitle=True,metaData=metaData)
                
        if len(blocks)>15:
            self.addDir("next page",url,100,'img/next.png','',str(page+1))
    ###############################################series
    def getseries(self,name,url,page,metaData):
        if page>1:
            page_url=url+"&page="+str(page)+"&order=DESC"
        

        else:
            page_url=url

        data=self.getPage(page_url)
        blocks=data.split('class="col-xs-6 col-sm-4 col-md-3"')
        blocks.pop(0)
        print "blocks",len(blocks)
        for block in blocks:
            regx='<a href="(.*?)" title'
            href=self.getSM(block,regx)
            regx='alt="(.*?)"'
            title=self.getSM(block,regx)
            regx='data-echo="(.*?)"'
            image=self.getSM(block,regx)
            #regx='<span>(.*?)</span>'
            #year=self.getSM(block,regx)
            #print "Year_xxxxxxxxxxxxxxxxxxxxx:",year_
            #year=self.removeunicode(year)
            
            #year=re.search(r'\d{4}', year).group()
            #try:year =  re.findall(r'\d+', year_)[1]
            #except:year=''
            #print "year",year
            title=title.replace("&#8217","-")
            title=title.replace("&#039","'")
            title=title.replace('&#8211;','-')
            title=title.replace('&#038;','&')
            title=title.replace("&#8230","...")
            title=title.replace(';','')
            #regx='''<span class="quality">(.*?)</span>'''
            #fTitle,year_=filterTitle(self,title)
            metaData={"name":title,"show":"tv"}
            self.addDir(title,href,201,image,name,1,maintitle=True,metaData=metaData)
                
        if len(blocks)>15:
            self.addDir("next page",page_url,200,'img/next.png','',str(page+1))
    def getseasons(self,name,url,page,image,metaData):
        self.addDir(name,url.replace('/video','/play'),1,image,name,1,maintitle=True,metaData=metaData)
        data=self.getPage(url)
        blocks=data.split('class="SeasonsEpisodes"')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='data-serie="(.*?)"'
            season=self.getSM(block,regx)
            regx='href="'
            print "SEASON:",season
            metaData['show_url']=url
            metaData['season']=season
            self.addDir(season+' الموسم','href',202,image,name,1,maintitle=True,metaData=metaData)
       
    def getepisodes(self,name,url,page,image,metaData):
        data_=self.getPage(metaData['show_url'])
        
        regx=';" data-serie="%s"(.*?)</div>'%metaData['season']
        data=self.getSM(data_,regx)
        blocks=data.split('<a class="')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='title="(.*?)"'
            title=self.getSM(block,regx)
            regx='href="(.*?)"'
            href=self.getSM(block,regx)   
            self.addDir(title,href.replace('./video',base_url+'/play'),1,image,name,1,maintitle=True,metaData=metaData)
        #self.addDir(name+" حلقة "+ep_num,href,1,'image',name,1,maintitle=True,metaData=metaData)


        
    #######################################host resolving
    def getservers1(self,name,url,img,metaData):
        printD("input-meta",metaData)
        if metaData.get("imdb_id",'')=="":
            metaData=self.updateMeta(metaData)
            printD("output-meta",metaData)

        data=self.getPage(url)
        blocks=data.split('class="watchButton')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            if 'data-embed="' in block:
                regx='data-embed="(.*?)"'
            else:
                regx="data-embed='(.*?)'"
            srv_url=self.getSM(block,regx)
            regx='</span>(.*?)</button>'
            srv=self.getSM(block,regx)
            self.addDir(srv,srv_url, 2,img,name,1,metaData=metaData,style='servers')
       
        return

    def getservers2(self,name,url,img,metaData):
        HDR_CM2={'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Armor 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36',
                'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'fr-FR,fr;q=0.9,ar-TN;q=0.8,ar;q=0.7,en-US;q=0.6,en;q=0.5',
                'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'Sec-Fetch-Dest': 'iframe',
                'Referer': 'https://cimalek.club/',
                'Accept-Encoding': 'gzip, deflate, br'}
        printD("input-meta",metaData)
        if metaData.get("imdb_id",'')=="":
            metaData=self.updateMeta(metaData)
            printD("output-meta",metaData)
        srv=metaData['server']
        embed_url=metaData['embed_url']
        if 'https://cimalek.club/redirect/' in embed_url:
            data=requests.get(embed_url,headers=HDR_CM2,verify=False,allow_redirects=True).content
            regx='noreferrer" href="(.*?)"'
            stream_url=self.getSM(data,regx)
            self.addDir(srv, stream_url, 0,img,name,1,metaData=metaData,style='servers')
        elif "zorona" in embed_url:
            try:
                iframe_jsdata=requests.get(embed_url,headers=HDR_CM2,verify=False).content
                
                if 'sources":' in iframe_jsdata:
                    if 'sources":{' in iframe_jsdata:
                        regx='sources":{(.*?)}'
                    elif 'sources":[{' in iframe_jsdata:
                        regx='sources":\[{(.*?)}'
                              
                    jsd_=self.getSM(iframe_jsdata,regx)
                    print "JSDxxxxxxxxxxxxxxxxxxxxxxxxx",jsd_
                    json_data = '[{%s}]'%jsd_
                    j_list=json.loads(json_data)
                    for d in j_list:
                        print "TARGETxxxxxxxxxxxxxxxxxxxxxxxxxx:",d.get('file')
                        self.addDir(srv, d.get('file'), 0,img,name,1,metaData=metaData,style='servers')
                elif 'var doc = {"uri":' in iframe_jsdata:
                    regx='var doc = {(.*?)}'
                    jsd_=self.getSM(iframe_jsdata,regx)
                    json_data = '[{%s}]'%jsd_
                    j_list=json.loads(json_data)
                    for d in j_list:
                        print "TARGETxxxxxxxxxxxxxxxxxxxxxxxxxx:",d.get('file')
                        self.addDir(srv, d.get('url'), 2,img,name,1,metaData=metaData,style='servers')
            except:
                printE()
                pass
        else:
            self.addDir(srv,embed_url, 2,img,name,1,metaData=metaData,style='servers')
            
        return
                
    def resolve_host(self,name,url,image):
        if os_platform=="win32" or os_platform=="win64":
            u_referer = ' :http-referrer="'+url+'"'
            
        else:
            u_referer = '#Referer='+url
            u_agent   = '#User-Agent=VLC/3.0.16 LibVLC/3.0.16'
        
        if "gvid.one" in url:
            stream_url=get_govid_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
            
        elif 'uptobox' in url or 'uptostream' in url:
            stream_url=get_uptoboxstream_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "uqload" in url:
            stream_url = get_uqload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "goved" in url:
            stream_url=get_goved_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vidbem" in url or "vidbm" in url or "vidbam" in url or "vadbam" in url:
            stream_url=get_vidbam_srvx(url)
            #self.addDir(name+' ['+vid_qlt+']',stream_url,0,'',name+' ['+vid_qlt+']',1)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
            
        elif "vidshar" in url or "viidshar" in url:
            stream_url=get_vidsharorg_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "upstream" in url:
            stream_url=get_upstream_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "myviid" in url:
            stream_url=get_myviid_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "dood" in url:
            stream_url=get_doodstream_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vudeo" in url:
            stream_url=get_vudeo_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "streamtape" in url:
            stream_url=get_streamtape_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "userload" in url:
            stream_url=get_userload_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vod540" in url:
            stream_url=get_vod540_srvx(url)    
            self.addDir(name,stream_url,0,'',name,1)
        elif "film77" in url:
            stream_url=get_auto_detect_srvx(resolver_engine+url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vidroba" in url:
            stream_url=get_vidroba_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vidspeeds" in url:
            stream_url=get_auto_detect_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vk.com" in url:
            stream_url=get_vk_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "media70" in url:
            stream_url=get_media70_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "skyvid" in url:
            stream_url=get_skyvid_srvx(url)
            if os_platform=="win32" or os_platform=="win64":
                self.addDir(name,stream_url,0,'',name,1)
            else:
                self.addDir(name,stream_url+u_agent,0,'',name,1)
        else:
            self.resolvehost(name,url) 
    def run(self):
        if self.cParams is None:
            self.cParams=self.get_params()
        name=self.cParams.get("name",None)
        url=self.cParams.get("url",None)
        dialog=self.cParams.get("dialog",None)
        try:mode=int(self.cParams.get("mode",None))
        except:mode=None
        image=self.cParams.get("image",None)
        section=self.cParams.get("section",None)
        page=int(self.cParams.get("page",1))
        extra=self.cParams.get("extra",{})
        try:extra=ast.literal_eval(extra)
        except:extra={}
        metaData=self.cParams.get('metaData',{})
        show=self.cParams.get("show",None)
        if mode==None :
            self.showmenu()
        elif mode==1:
            self.getservers1(name,url,image,metaData)
        elif mode==2:
            self.resolve_host(name,url,image)
        elif mode==4:
            self.getservers2(name,url,image,metaData)
        elif mode==6:
            if "govid.co" in url:self.resolve_host(name,url,image)
            else:self.resolvehost(name,url)
        elif mode==100:
            self.getmovies(name,url,page,metaData)
        elif mode==110:
            self.Years()
        elif mode==120:
            self.Genres()
        elif mode==103:
            sterm = self.getsearchtext()
            self.search("Search",sterm,page,metaData)
         
        elif mode==105:
            self.get_actors(name,url,page,metaData)
        elif mode==200:
            self.getseries(name,url,page,metaData)
        elif mode==201:
            self.getseasons(name,url,page,image,metaData)
        elif mode==202:
            self.getepisodes(name,url,page,image,metaData)
        elif mode==203:
            self.search_tvshows(url)
        return self.endDir()
def start(cParams=None):
    addon=laroza(cParams)
    addon._iniAddon()
    return addon.run()


