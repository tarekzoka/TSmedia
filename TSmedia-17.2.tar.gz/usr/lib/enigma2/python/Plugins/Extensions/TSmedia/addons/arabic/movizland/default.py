# -*- coding: utf8 -*-
import urllib,urllib2,re,sys,os,ast,warnings
from iTools import CBaseAddonClass,printD,printE
from hosts.tstls import *
from tslib import requests
from tslib.requests.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
##########################################
os_platform=sys.platform

baseurl = 'https://w2.movizland.icu'
HDR={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
     'Referer':baseurl,
     'Accept-Encoding':'gzip, deflate'}
def filterTitle(self,title):
    year=''
    try:
        title=self.removeunicode(title)
        #print "title1",title
        try:year =  re.findall(r'\d+', title)[0]
        except:year=''
        #print "year",year
        title=title.replace(year,'').strip()
        #print "title2",title
        return title,year
    except:
        return title,year

class movizland(CBaseAddonClass):
        def __init__(self,cParams):
                self.cParams=cParams
                CBaseAddonClass.__init__(self,{'cookie':'movizland.cookie'})
		self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
		self.MAIN_URL = baseurl
		self.HEADER = {'User-Agent': self.USER_AGENT, 'Connection': 'keep-alive', 'Accept-Encoding':'gzip','Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
		self.defaultParams = {'header':self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

        def showmenu(self):
                baseurl=self.MAIN_URL
                self.addDir('Search',baseurl+'/?s=',103,'img/0.png','',1,searchall=__file__)
                self.addDir('اخــر الاضــافات',baseurl+'/',100,'img/12.png','',1)
                self.addDir('افلام اجنبية',baseurl+'/category/movies/foreign',100,'img/1.png','',1)
                self.addDir('السنوات','url',800,'img/16.png','',1)
                self.addDir('أفلام مصنفة','url',30,'img/15.png','',1)
                self.addDir('3D',baseurl+'/category/movies/3d/',100,'img/1.png','',1)
                self.addDir('4K',baseurl+'/category/movies/4k',100,'img/1.png','',1)
                #self.addDir('طلبات الاعضاء',baseurl+'/tags/?q=submition',136,'img/14.png','',1)
                #self.addDir('بوكس اوفيس',baseurl+'/tags/?q=boxoffice',106,'img/17.png','',1)
                self.addDir('جودة عالية',baseurl+'/?type=quality&s=720p+HDTV',300,'img/18.png','',1)
                #self.addDir('افلام عربية',baseurl+'/category/movies/arab/',100,'img/2.png','',1)	
                self.addDir('افلام هندية',baseurl+'/category/movies/india/',100,'img/3.png','',1)
                self.addDir('افلام تركية',baseurl+'/category/movies/turkey/',100,'img/8.png','',1)
                self.addDir('افلام اسيوية',baseurl+'/category/movies/asia/',100,'img/10.png','',1)
                self.addDir('افلام وثائقية',baseurl+'/category/movies/documentary/',100,'img/9.png','',1)
                self.addDir('افلام انيميشن',baseurl+'/category/movies/anime/',100,'img/4.png','',1)
                self.addDir('مسلسلات اجنبيه',baseurl+'/category/series/foreign-series/',200,'img/6.png','',1)
                self.addDir('مسلسلات تركية',baseurl+'/category/series/turkish-series/',200,'img/6.png','',1)
                #self.addDir('مسلسلات عربيه',baseurl+'/category/series/arab-series',200,'img/5.png','',1)
                self.addDir('سلاسل ومكتبات',baseurl+'/category/movies/backs',200,'img/5.png','',1)
                
                self.addDir('WWE',baseurl+'/category/series/wwe/',100,'img/11.png',1)
              
                #self.addDir('برامج تلفزيونية',baseurl+'/category/series/tv-progs/',200,'img/13.png','',1)
                
        def GENRES(self,url):
                self.addDir('••أفلام رعـــب••',baseurl+'/all/%D8%B1%D8%B9%D8%A8/',100,'img/1.png','',1)
                self.addDir('••الجريمة••',baseurl+'/all/%d8%ac%d8%b1%d9%8a%d9%85%d9%87/',100,'img/2.png','',1)
                self.addDir('••أفلام رومــــانسية••',baseurl+'/all/%d8%b1%d9%88%d9%85%d8%a7%d9%86%d8%b3%d9%8a/',100,'img/3.png','',1)
                self.addDir('••مغامرات••',baseurl+'/all/%d9%85%d8%ba%d8%a7%d9%85%d8%b1%d9%87/',100,'img/4.png','',1)
                self.addDir('••كـــومديـــا••',baseurl+'/all/%d9%83%d9%88%d9%85%d9%8a%d8%af%d9%8a/',100,'img/5.png','',1)
                self.addDir('••درامــــــــــــا••',baseurl+'/all/%d8%af%d8%b1%d8%a7%d9%85%d8%a7/',100,'img/6.png','',1)
                self.addDir('••الحرب••',baseurl+'/all/%d8%ad%d8%b1%d8%a8/',100,'img/7.png','',1)
                self.addDir('••أفلام أكشــــن••',baseurl+'/all/%d8%a7%d9%83%d8%b4%d9%86/',100,'img/8.png','',1)
                self.addDir('••الخيال العلمي••',baseurl+'/all/%d8%ae%d9%8a%d8%a7%d9%84-%d8%b9%d9%84%d9%85%d9%8a/',100,'img/12.png','',1)
                
                
                
        
                
                
        def years(self,url):
                self.addDir('2023',baseurl+'/?type=year&s=2023',100,'img/00.png','',1)
                self.addDir('2022',baseurl+'/?type=year&s=2022',100,'img/00.png','',1)
                self.addDir('2021',baseurl+'/?type=year&s=2021',100,'img/00.png','',1)
                self.addDir('2020',baseurl+'/?type=year&s=2020',100,'img/00.png','',1) 
                self.addDir('2019',baseurl+'/?type=year&s=2019',100,'img/00.png','',1)  
                self.addDir('2018',baseurl+'/?type=year&s=2018',116,'img/00.png','',1)        
        
                self.addDir('2017',baseurl+'/?type=year&s=2017',116,'img/00.png','',1)        
        
                self.addDir('2016',baseurl+'/?type=year&s=2016',116,'img/00.png','',1)        
                self.addDir('2015',baseurl+'/?type=year&s=2015',116,'img/00.png','',1)      
                self.addDir('2014',baseurl+'/?type=year&s=2014',116,'img/00.png','',1)
                self.addDir('2013',baseurl+'/?type=year&s=2013',116,'img/00.png','',1)        
                self.addDir('2012',baseurl+'/?type=year&s=2012',116,'img/00.png','',1)      
                self.addDir('2011',baseurl+'/?type=year&s=2011',116,'img/00.png','',1)
                self.addDir('2010',baseurl+'/?type=year&s=2010',116,'img/00.png','',1)        
                self.addDir('2009',baseurl+'/?type=year&s=2009',116,'img/00.png','',1)      
                self.addDir('2008',baseurl+'/?type=year&s=2008',116,'img/00.png','',1)
                self.addDir('2007',baseurl+'/?type=year&s=2007',116,'img/00.png','',1)      
                self.addDir('2006',baseurl+'/?type=year&s=2006',116,'img/00.png','',1)      
                self.addDir('2005',baseurl+'/?type=year&s=2005',116,'img/00.png','',1)
                self.addDir('2004',baseurl+'/?type=year&s=2004',116,'img/00.png','',1)        
                self.addDir('2003',baseurl+'/?type=year&s=2003',116,'img/00.png','',1)        
                
               

        
        ####################movies		
                       
        def getyears_movies(self,url):
                for i in range(2002,2016):
                     self.addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                            
        def getgenre_movies(self,url):
                #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
                genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
                for item in genrelist:
                        
                         self.addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg','',1)
                
        
                                    
                            
        
        
        def getA_Z_movies(self,name,mode):
                AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
                for character in AZ_DIRECTORIES:
                        #http://www.vidics.ch/Category-Movies/Genre-Any/
                        self.addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"",'',1)
                                
                                          
        def search(self,name,sterm,page):
               
                if page>1:
                        url_page=baseurl+'/?s=%s&page=%s'%(sterm,str(page))
                else:
                        url_page=baseurl+'/?s=%s'%sterm
                
                #data=self.getPage(url_page)
                data=requests.get(url_page,headers=HDR,verify=False).content                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="BlockItem"')
                i=0
                
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    #regx='''href="(.*?)"'''
                    regx='href="(.*?)"'
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    #print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''alt="(.*?)"'''
                    
                    try:title=re.findall(regx,block, re.M|re.I)[0]
                    except:title=os.path.split(href[:-1])[1]
                    fTitle,year=filterTitle(self,title)

                    if "مسلسل" in title:
                        show='tv'
                    else:
                        show='movie'
                    metaData={"name":fTitle,"year":year,"show":show}
                    #print "metaData",metaData                                   

                    quality=self.getDM(block,'desktop"></i>','</li>',False)
                    quality=quality.strip()
                    try:
                      regx='''<span>(.*?)</span>'''
                      genre=re.findall(regx,block.split('class="RestInformation"')[1], re.M|re.I)[0]
                    except:
                            pass
                      
                    try:
                        regx='<strong>(.*?)</strong>'
                        rating=self.getSM(block,regx)
                        title=title+"("+rating +" " +quality+ " "+genre+")"
                    except:
                           
                            rating=''
                            pass
                    
                    #print "title",title
                  
                    
                    
                    #title=self.colorize(title)
                    self.addDir(title,href,1,img,name,1,True,metaData=metaData)
                    
                print "page",page,len(blocks)
                
                if len(blocks)>85:
                   self.addDir("next page",sterm,103,'img/next.png','',str(page+1),dialog='Nosearch')                
                if len(blocks)==0:
                    self.addDir("Error:no results",sterm,100,'','',str(page+1))


        
        def getmovies(self,main_name,urlmain,page):
                        if page>1:
                          url_page=urlmain+'/page/'+str(page)
                          url_page=urlmain+"/page/"+str(page)+"/"
                          
                          
                        else:
                        
                              url_page=urlmain
                        #data=self.getPage(url_page)
                        data=requests.get(url_page,headers=HDR,verify=False).content                  
                       
                        if data is None:
                            return
                        #print dataclass="vi-box-top"
                        blocks=data.split('class="BlockItem"')
                        i=0
                        
                        print "blocks",len(blocks)
                        for block in blocks:
                            i=i+1
                            if i==1:
                                    continue
                            
                           
                            
                            #regx='''href="(.*?)"'''
                            regx='href="(.*?)"'
                            try:href=re.findall(regx,block, re.M|re.I)[0]
                            except:continue
                            
                            
                            regx='''src="(.*?)"'''
                            try:img=re.findall(regx,block, re.M|re.I)[0]
                            except:img=''
                            #print "img",img.strip()    
                           
                            #regx='''<div class="small-play">'''
                            regx='''alt="(.*?)"'''
                            
                            try:title=re.findall(regx,block, re.M|re.I)[0]
                            except:title=os.path.split(href[:-1])[1]
                            title=title.replace("&#039;","'")
                            fTitle,year=filterTitle(self,title)
                            metaData={"name":fTitle,"year":year,"show":'movie'}
                            #print "metaData",metaData

                            quality=self.getDM(block,'desktop"></i>','</li>',False)
                            quality=quality.strip()
                            try:
                              regx='''<span>(.*?)</span>'''
                              genre=re.findall(regx,block.split('class="RestInformation"')[1], re.M|re.I)[0]
                            except:
                                    pass
                              
                            try:
                                regx='<strong>(.*?)</strong>'
                                rating=re.findall(regx,block, re.M|re.I)[0]
                                title=title+"("+rating +" " +quality+ " "+genre+")"
                            except:
                                    #printE()
                                    rating=''
                                    pass
                            
                            #print "title",title
                          
                            
                            
                            title=self.colorize(title,"green")
                            try:self.addDir(title,href,1,img,main_name,1,True,metaData=metaData)
                            except:continue
                        print "page",page,len(blocks)
                        
                        if len(blocks)>85:
                           self.addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1),dialog='Nosearch')                
                        if len(blocks)==0:
                            self.addDir("Error:no results",urlmain,100,'','',str(page+1))
        
        
        
        def getHD(self,main_name,urlmain,page):
                        if page>1:
                          #https://tv1.movizland.online/page/2/?type=quality&s=720p+HDTV
                          url_page='https://tv1.movizland.online/page/%s/?type=quality&s=720p+HDTV'%str(page)
                         
                         
                          
                        else:
                        
                              url_page=urlmain
                        #data=self.getPage(url_page)
                        data=requests.get(url_page,headers=HDR,verify=False).content 
                                          
                       
                        if data is None:
                            return
                        #print dataclass="vi-box-top"
                        blocks=data.split('class="BlockItem"')
                        i=0
                        
                        print "blocks",len(blocks)
                        for block in blocks:
                            i=i+1
                            if i==1:
                                    continue
                            
                           
                            
                            #regx='''href="(.*?)"'''
                            regx='href="(.*?)"'
                            try:href=re.findall(regx,block, re.M|re.I)[0]
                            except:continue
                            
                            
                            regx='''src="(.*?)"'''
                            try:img=re.findall(regx,block, re.M|re.I)[0]
                            except:img=''
                            #print "img",img.strip()    
                           
                            #regx='''<div class="small-play">'''
                            regx='''alt="(.*?)"'''
                            
                            try:title=re.findall(regx,block, re.M|re.I)[0]
                            except:title=os.path.split(href[:-1])[1]
                            fTitle,year=filterTitle(self,title)
                            metaData={"name":fTitle,"year":year,"show":'movie'}
                            #print "metaData",metaData                                                

                            quality=self.getDM(block,'desktop"></i>','</li>',False)
                            quality=quality.strip()
                            try:
                              regx='''<span>(.*?)</span>'''
                              genre=re.findall(regx,block.split('class="RestInformation"')[1], re.M|re.I)[0]
                            except:
                                    pass
                              
                            try:
                                regx='<strong>(.*?)</strong>'
                                rating=re.findall(regx,block, re.M|re.I)[0]
                                title=title+"("+rating +" " +quality+ " "+genre+")"
                            except:
                                    #printE()
                                    rating=''
                                    pass
                            
                            #print "title",title
                          
                            
                            
                            #title=self.colorize(title)
                            try:self.addDir(title,href,1,img,main_name,1,True,metaData=metaData)
                            except:continue
                        print "page",page,len(blocks)
                        
                        if len(blocks)>53:
                           self.addDir("next page",urlmain,300,'img/next.page','',str(page+1),dialog='Nosearch')                
                        
        

                       
                                            
        def getseries(self,main_name,urlmain,page):
                        if page>1:
                          #https://tv1.movizland.online/category/series/foreign-series/page/2/
                          #https://tv1.movizland.online/category/series/foreign-series/page/4/
                          #url_page=urlmain+"page/%s/"%str(page)
                          url_page=urlmain+'/page/'+str(page)
                         
                          
                        else:
                        
                              url_page=urlmain

                        #print 'url_page',url_page
                      
                        #data=self.getPage(url_page)
                        data=requests.get(url_page,headers=HDR,verify=False).content                  
                       
                        if data is None:
                            return
                        #print dataclass="vi-box-top"
                        blocks=data.split('class="BlockItem"')
                        i=0
                        
                        print "blocks",len(blocks)
                        for block in blocks:
                            i=i+1
                            if i==1:
                                    continue
                            
                           
                            
                            #regx='''href="(.*?)"'''
                            regx='href="(.*?)"'
                            try:href=re.findall(regx,block, re.M|re.I)[0]
                            except:continue
                            
                            
                            regx='''src="(.*?)"'''
                            try:img=re.findall(regx,block, re.M|re.I)[0]
                            except:img=''
                            #print "img",img.strip()    
                           
                            #regx='''<div class="small-play">'''
                            regx='''alt="(.*?)"'''
                            
                            try:title=re.findall(regx,block, re.M|re.I)[0]
                            except:title=os.path.split(href[:-1])[1]
                            fTitle,year=filterTitle(self,title)
                            metaData={"name":fTitle,"year":year,"show":'tv'}
                            #print "metaData",metaData                                                
                                                     

                            quality=self.getDM(block,'desktop"></i>','</li>',False)
                            quality=quality.strip()
                            try:
                              regx='''<span>(.*?)</span>'''
                              genre=re.findall(regx,block.split('class="RestInformation"')[1], re.M|re.I)[0]
                            except:
                                    pass
                              
                            try:
                                regx='<strong>(.*?)</strong>'
                                rating=re.findall(regx,block, re.M|re.I)[0]
                                title=title+"("+rating +" " +quality+ " "+genre+")"
                            except:
                                    rating=''
                                    pass
                            
                            #print "title",title
                          
                            
                            
                            #title=self.colorize(title)
                            try:self.addDir(title,href,202,img,main_name,1,True,metaData=metaData)
                            except:continue
                        print "page",page,len(blocks)
                        
                        if len(blocks)>50:
                           self.addDir("next page",urlmain,200,'img/next.png','',str(page+1),dialog='Nosearch')                
                        if len(blocks)==0:
                            self.addDir("Error:no results",urlmain,200,'','',str(page+1))
        
        
                            


        def getseasons(self,name,urlmain,page,metaData):
                       data=requests.get(urlmain,headers=HDR,verify=False).content
                       
        def getepisodes(self,name,urlmain,page,metaData={}):
                        metaData=self.updateMeta(metaData)
                        print "metaData",metaData
                       

                        #data=self.getPage(urlmain)
                        data=requests.get(urlmain,headers=HDR,verify=False).content                  
                        regx='class="BlocksInner">(.*?)</div> '
                        data_=self.getSM(data,regx)
                        regx='<a href="(.*?)"'
                        href_=self.getSM(data_,regx)
                        data=requests.get(href_,headers=HDR,verify=False).content 
                        blocks=data.split('class="BlockItem">')
                        i=0
                        
                        print "blocks",len(blocks)
                        for block in blocks:
                            i=i+1
                            if i==1:
                                    continue
                            
                           
                            
                            #regx='''href="(.*?)"'''
                            regx='href="(.*?)"'
                            try:href=re.findall(regx,block, re.M|re.I)[0]
                            except:continue
                            
                            
                            regx='''src="(.*?)"'''
                            try:img=re.findall(regx,block, re.M|re.I)[0]
                            except:img=''
                            
                           
                           
                            regx='''<em>(.*?)</em>'''
                            
                            try:title=re.findall(regx,block, re.M|re.I)[0]+' حلقة'
                            except:title=os.path.split(href[:-1])[1]
                                                     

                            
                            #print "title",title
                          
                            
                            
                            #title=self.colorize(title)
                            self.addDir(title,href,1,img,name,1,True,metaData=metaData,style='servers')
                            
                
        def getlinksss(self,name,url,img,metaData={}):
                if metaData.get("imdb_id",'')=='':
		   metaData=self.updateMeta(metaData)##change4
		print "metaData",metaData
		
		urlTab = []	
		post_data = {'watch':'1'}
		#r = self.getPage(url,post_data=post_data)
		data = requests.get(url,headers=HDR,verify=False).content
		blocks=data.split('<code id=')
                i=0
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                        continue
                    
                    try:
                        regx='data-srcout="(.*?)"'
                        srv_url=re.findall(regx,block, re.M|re.I)[0]
                        srv_url=re.sub(r"[\n\t\s]*", "", srv_url)
                    except:pass
                    
                    if 'moshahda' in srv_url:
                        regx='data-server="main">(.*?)</li>'
                    else:
                        regx= '''data-server.*?">(.*?)</li>'''
                    
                    try:
                        server=re.findall(regx,block, re.M|re.I)[0]
                        #print "SERVERxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",server
		    except:pass
		   
		    self.addDir(server, srv_url, 2,'img',metaData=metaData,style='servers')
		"""if r:
			rgx = '''EmbedCode">.*?<IFRAME.*?SRC="(.*?)"'''
			iframe = re.findall(rgx,r,re.S)
			for (href) in iframe:
				if '.mpd' in href or 'code=' in href:continue
				if 'moshahda' in href:
					href = self.get_moshahda(href)
					iframe = re.findall('{file:"(.*?)"(.*?)}',href,re.S)
					for (url,label) in iframe:
						if '.mpd' in url or 'code=' in url:continue
						if 'm3u8' in url: label='HLS'
						label='Moshahada ['+label.replace(',label:"','').replace('"','')+']'						
						if 'm3u8' in url:
							self.addDir(label, url,2,img,name,metaData=metaData,style='servers')
						else:
							self.addDir(label, url,metaData=metaData,style='servers')
			rgx = '''<li data-server.*?">(.*?)<.*?SRC="(.*?)"'''
			iframe = re.findall(rgx,r,re.S)
			
			for (server,href) in iframe:
				if '.mpd' in href or 'code=' in href:continue
				self.addDir(server, href, 2,img,metaData=metaData,style='servers')#chnage5"""
	def getlinks(self,name,url,img,metaData={}):
            printD("input-meta",metaData)
            if metaData.get("imdb_id",'')=="":
                metaData=self.updateMeta(metaData)
                printD("output-meta",metaData)
            #urlTab = []	
            #post_data = {'watch':'1'}
            #r = self.getPage(url,post_data=post_data)
            data = requests.get(url,headers=hdr,verify=False).content
            regx='postPlayer">(.*?)<div'
            data_=self.getSM(data,regx)
            regx='href="(.*?)"'
            url_=self.getSM(data_,regx)
            #print url_
            data_=requests.get(url_,headers=HDR,verify=False).content
            regx='<div class="ServersEmbeds">(.*?)</div>'
            block_part=self.getSM(data_,regx)
            #print block_part
            blocks=block_part.split('data-se')#id="EmbedS
            blocks.pop(0)
            print "blocks",len(blocks)
            for block in blocks:
                if "rver='" in block:
                    regx="rver='(.*?)</li>"
                    server=self.getSM(block,regx)[6:]
                else:
                    regx='rver="(.*?)</li>'
                    server=self.getSM(block,regx)[3:]
                
                regx='rcout="(.*?)"'
                href=self.getSM(block,regx).rstrip()
                href=href.replace('\n','')
                self.addDir(server,href,2,img,name,metaData=metaData,style='servers')
            """if r:
			rgx = '''id="EmbedS.*?<IFRAME.*?SRC="(.*?)"'''
			iframe = re.findall(rgx,r,re.S)
			print "iframe",iframe
			for (href) in iframe:
			    if '.mpd' in href or 'code=' in href:continue
			    if 'moshahda' in href:
                                print "MOSHAHDA HREFxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",href
			        href = self.get_moshahda(href+"::"+url)
			        iframe = re.findall('{file:"(.*?)"(.*?)}',href,re.S)
			        for (url,label) in iframe:
			            if '.mpd' in url or 'code=' in url:continue
			            if 'm3u8' in url: label='HLS'
			            label='Moshahada ['+label.replace(',label:"','').replace('"','')+']'						
			            if 'm3u8' in url:
			                self.addDir(label, url.lower(),2,img,name,metaData=metaData,style='servers')
			            else:
			                self.addDir(label, url.lower(),metaData=metaData,style='servers')
			rgx = '''<li data-server.*?">(.*?)<.*?SRC="(.*?)"'''
			tmx = '''<li data-server=".+?">(.+?)</li>.+?<code id="EmbedSc.+?".+?><iframe allowfullscreen data-srcout="(.+?)"'''
			_iframe = re.findall(tmx,r,re.S)
			print "_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe_iframe === ",_iframe
			iframe = re.findall(rgx,r,re.S)
			print "iframe",iframe
			for (server,href) in _iframe:
			    if '.mpd' in href or 'code=' in href:continue
			    href = href.replace('\r','')
			    self.addDir(server, href.lower(), 2,img,metaData=metaData,style='servers')#chnage5	"""
	def get_moshahda(self,urlo):
		r = self.getPage(urlo)
		if r:
			tmx = '''sources:.*?\[(.*?)\]'''
			video = re.findall(tmx,r)
			if video: return video[0]
			else:
			    Link = get_video_url(urlo)
			    if Link:
			        print Link
			        return Link
			    else:return '[]'
		else:
                        return []
			    
        					
        def resolveLinks(self,name,url):
            pattern = "[\r\n|\n]"
            url=url.rstrip()
            if os_platform=="win32" or os_platform=="win64":
                u_referer = ' :http-referrer="'+url+'"'
            else:
                u_referer = '#Referer='+url
                u_agent   = '#User-Agent=VLC/3.0.16 LibVLC/3.0.16'
            
            if "cloudvideo" in url:
                stream_url=get_cloudvideo_srvx(url)
                self.addDir(name,stream_url,0,'',name,1)
            elif "moshahda" in url :
                stream_url=get_moshahda_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)    
            elif "upstream" in url:
                stream_url=get_upstream_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif "vidbam" in url or "vadbam" in url:
                stream_url=get_vidbam_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif "vidshar" in url or "viidshar" in url:
                stream_url=get_vidsharorg_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif "dood" in url:
                stream_url=get_doodstream_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif "govad" in url or "goved" in url or "govid" in url:
                stream_url=get_goved_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif "streamtape" in url:
                stream_url=get_streamtape_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif 'uqload' in url:
                stream_url = get_uqload_srvx(url)
                self.addDir(name, stream_url + u_referer, 0, '', name, 1)
            elif 'youdbox' in url or 'yodbox' in url:
                stream_url=get_youdbox_srvx(url)
                self.addDir(name,stream_url+u_referer,0,'',name,1)
            elif 'uptobox' in url or 'uptostream' in url:
                stream_url=get_uptoboxstream_srvx(url)
                self.addDir(name,stream_url,0,'',name,1)
                
            else:
                self.resolvehost(name,url)			
        					
        					
##########################################################metadata################################
    ##please use in same format 
        def metaData(self,url='',image='',data='',extra={},desc='',show='movie'):#TmX
                        if data=='':
                                data=self.getPage(url)                
                        #if show=='tv':
                           #extra,desc,image=self.metaDataTV(url='',image='',data=data,extra={},desc='')
                           #return extra,desc,image

                        ##standard params remove not needed params from the list
                        #params=['rating','quality','year','country','language','duration'
                                #'pg','genres','trailer','image','desc']
                        params=['rating','quality','country','language','year','duration',
                                'genres','image','desc']
                        if 'rating' in params:    
                            regx='''<em>(.+?)</em>'''
                            try:extra['rating']=self.getSM(data.split('class="LeftIMDBBox"')[1],regx)
                            except:extra['rating']=''
                        if 'quality' in params:
                            regx='''<a href="https://on.movizland.com/quality/.+?">(.+?)</a>'''
                            extra['quality']=self.getSM(data,regx)
                            
                        if 'year' in params:
                            
                            extra['year']=self.getDM(data,'سنة الإنتاج : </span>','</li>').strip()
                            
                        ######country
                        if 'country' in params:
                            regx='''<a href="https://on.movizland.com/country/.+?">(.+?)</a>'''
                            extra['country']=self.getSM(data,regx)
                            
                        if 'language' in params:
                            regx='''<a href="https://on.movizland.com/language/.+?">(.+?)</a>'''
                            language=self.getSM(data,regx)
                            extra['language']=self.cleanhtml(language)
                            
                        if 'duration' in params:    

                            extra['duration']=self.cleanhtml(self.getDM(data,'مدة العرض :','<li>'))
                            
                        if 'pg' in params:
                            pg=self.getDM(data,'التصنيف</td>','</tr>',False)
                            extra['pg']=self.cleanhtml(pg)

                        if 'genres' in params:
                            regx='''<a href="https://on.movizland.com/genre/.+?">(.+?)</a>'''
                            genres=self.getSM(data,regx)
                            extra['genres']=genres
                            
                        if 'trailer' in params:   
                            regx='''<iframe allowfullscreen name="trailer" src="" data-ifr="(.+?)".+?></iframe>'''
                            
                            trailer=self.getSM(data,regx)
                            print 'trailer',trailer
                            if 'imdb.com' in trailer:
                                print 'trailer2',trailer
                                

                                imdbTrailer,imdb_id,videoURL=getIMDBParams(imdbTrailer=trailer,imdb_id='')
                                extra['imdb_id']=imdb_id
                                print "imdb_id",imdb_id                    
                            extra['trailer']=trailer        
                        if 'image' in params:
                            regx='''<span style="background-image: url((.+?));"></span>'''
                            image=self.getSM(data,regx)

                        if 'desc' in params:
                            regx='''<div class="StoryContent">(.+?)</div>'''
                            desc=self.getSM(data,regx)
                            desc=self.cleanhtml(desc)
                      

                        
                        return extra,desc,image        					
                                                        
        					
        					
        					
        					
        def run(self,params):
                self.cParams=params
                url=None
                name=None
                mode=None
                page=1
        
                printD("cParams-movizland",params)
                name=params.get("name",None)
                url=params.get("url",None)
                mode=params.get("mode",None)
                
                image=params.get("image",None)
                section=params.get("section",None)
                page=int(params.get("page",1))
                extra=params.get("extra",{})
                metaData=params.get("metaData",{})##change3
                show=params.get("show",None)
               
        
        
        
        
        
                print "Mode1: "+str(mode)
                print "URL: "+str(url)
                print "Name: "+str(name)
               
                print "page: "+str(page)
                print "section: "+str(section)
                print "show: "+str(show)
                print "extra: "+str(extra)
                if mode==None :
                        print ""
                        
                        self.showmenu()
                ##parsing tools        
                elif mode==1:
                        print ""+url
                        self.getlinks(name,url,image,metaData=metaData)##change2
                        
                elif mode==2:
                        print ""+url
                        self.resolveLinks(name,url)
                
                elif mode==55:
                        print ""+url                        
                        self.GENRES(url)
                
                ####movies        
                elif mode==100:
                        print ""+url
                        self.getmovies(name,url,page)

                elif mode==101:
                        print ""+url
                        self.getgenre_movies('movies')
        
                elif mode==102:
                        
                        self.getA_Z_movies(name,100)
        
                elif mode==104:
                        print ""+url
                        
                        self.getyears_movies(name)
                        
                                
                elif mode==103:
                        print ""+url
                        sterm=self.getsearchtext()
                        self.search(name,sterm,page)
        

        
                ###series        
                elif mode==200:
                        
                        self.getseries(name,url,page)
               
                elif mode==201:
                        self.getseasons(name,urlmain,page,metaData)
                        
                elif mode==202:
                        self.getepisodes(name,url,page,metaData)

                        
                elif mode==800:
                        print ""+url                
                        self.years(url)
                elif mode==30:
                        print ""+url        
                        self.GENRES(url)
               
                elif mode==300:
                        print ""+url        
                        self.getHD(name,url,page)        
                
               
                return self.endDir()

def start(params):
    addon=movizland(params)
    return addon.run(params)               
# -*- coding: utf8 -*-
Agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; …) Gecko/20100101 Firefox/65.0'}
hdr={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; E6633 Build/32.4.A.1.54)',
     'Accept-Encoding': 'gzip'}
import requests
import urllib2
import re
import requests,re
from jsunpack import unpack
def get_packed_data(html):
    packed_data = ''
    for match in re.finditer('(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            js_data = unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass
    return packed_data
def get_video_url(url):
    listServers= []
    import requests
    ses=requests.Session()
    response=ses.get(url)
    if response.status_code==200:
            data2=response.content
    else:
            return []
    if '(p,a,c,k,e,d)' in data2:
        data2 = get_packed_data(data2)
        return data2
    r = re.findall('file:"(.+?)"',data2)
    if r:
        for href in r:
            if '.mpd' in href or 'code=' in href:continue
            w = ('Cool_moshahda',href)
            listServers.append(w)
    else:
        w = ('Oops_moshahda','Error')
        listServers.append(w)
    return listServers




    
