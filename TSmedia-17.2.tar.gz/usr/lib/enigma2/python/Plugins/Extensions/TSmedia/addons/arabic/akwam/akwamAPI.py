# -*- coding: utf-8 -*-
import urllib2,re,requests
St = requests.Session()
from iTools import printE
import re
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
HDR={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Accept-Encoding': 'gzip, deflate',
     'Connection': 'keep-alive',
     'Upgrade-Insecure-Requests': '1'}
def Converttxt(tmp):
    tmp = urllib2.unquote(tmp)
    tmp = str(tmp).decode('utf-8')
    tmp = tmp.replace('\n','').replace(':','').replace('\n','').replace('\t','').replace('\s','').replace('\d','')
    return tmp
def metaData(self,url='',data='',extra={},desc='',image='',show='movie'):
    if data=='':
        self.getPage(url)
    regx='''<a href="https://www.imdb.com/title/(.*?)" target="_blank">'''
    imdb_id=self.getSM(data,regx)
    if '/?' in imdb_id:
        imdb_id=imdb_id.split('/?')[0]
    extra['imdb_id']=imdb_id
    print "imdb_id.",imdb_id
    regx='''<div class="text-white"><p>(.*?)</p></div>'''
    regx2='''<span style="color:#FFD700">.*?</span>(.*?)<br'''
    desc=self.getSM(data,regx)
    if desc=='':
        desc=self.getSM(data,regx2)
    desc=self.cleanhtml(desc)
    regx = '''<div class="font-size-16 text-white mt-2"><span>(.+?)</span>'''#country,year,duration
    match=self.getMM(data,regx)
    print "match",match
    try:
        extra['language'] = match[0]
        extra['translation'] = match[1]
        extra['country'] = match[2]
        extra['year'] = match[3]
        extra['duration'] = match[4]
    except:
        printE()
    regx='''class="badge badge-pill badge-light ml-2">(.+?)</a>'''
    extra['genres']=self.getMM(data,regx)
    regx='''<span>جودة الفيلم :(.+?)</span>'''
    if extra.get('quality','')=='':
               extra['quality']=self.getSM(data,regx)
    regx='''<span class="mx-2">(.+?)</span>'''
    if extra.get('rating','')=='':
               extra['rating']=self.getSM(data,regx)
    regx='''<span class="badge.+?"(.+?)</span>'''
    extra['pg']=self.getSM(data,regx)
    regx='''<a href="https://www.youtube.com/channel/(.+?)" target="_blank" class="youtube mx-2">'''
    extra['youtube']=self.getSM(data,regx)
    regx='''<picture><img src="(.+?)" class="img-fluid"'''
    image=self.getSM(data,regx)
    return extra,desc,image
def getLinks22(url):
    data=St.get(url,verify=False).content
    print "URLxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",url
    regx='''<a href="(.+?)" class="download-link"'''
    #regx='''<a href="(.+?)" class="link-btn link-show'''
    shortURL=re.findall(regx,data)[0]
    print 'shortURL_shortURL_shortURL_shortURL_shortURL_shortURL-------------------------------------------',shortURL
    data=St.get(shortURL,verify=False).content
    blocks=data.split("<source")
    blocks.pop(0)
    links=[]
    for block in blocks:
        regx='src="(.+?)"'
        href=re.findall(regx,block)[0]+'#Referer='+url
        regx='size="(.+?)"'
        size=re.findall(regx,block)[0]
        links.append((size+"__W",href))
    return links
def getLinks(self,data,url):
    size = ''
    link = ''
    List = []
    links=[]
    ###regx='''<a href="http://go.akwam.+?/watch/(.+?)"'''
    regx='''<a href="(.+?)" class="link-btn link-show d-flex align-items-center px-3">'''
    shortURL=self.getMM(data,regx)[0]
    ###linkoss = "https://go.akwam.cz/watch/"+str(shortURL)
    ###links = getLinks22(linkoss)
    links = getLinks22(shortURL)
    print "shortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURLshortURL",shortURL
    if "https" in data:regx='''<a href="https://go.akwam.+?/link/(.+?)"'''
    else:regx='''<a href="http://go.akwam.+?/link/(.+?)"'''    
    regx='''<a href="http://go.akwam.+?/link/(.+?)"'''#<a href="http://go.akwam.in/link/42724"
    shortURL=self.getMM(data,regx)
    for _id in shortURL:
        link = "http://go.akwam.cz/link/"+str(_id)
        print "linklinklinklinklinklinklinklinklinklinklinklinklinklink===================================",link
        ###data=self.getPage(link)
        data=requests.get(link,headers=HDR,verify=False).content
        regx='''<a href="(.+?)" target="_blank"'''
        watchURL=self.getSM(data,regx)
        print "watchURL_watchURL_watchURLwatchURL_watchURL_watchURLwatchURL_watchURL_watchURLwatchURL_watchURL_watchURL",watchURL
        wdata=St.get(watchURL,verify=False).content#self.getPage(watchURL)
        regx='<div class="btn-loader">.+?<a href="(.+?)".+?download'
        regx='<div class="btn-loader">.+?<a href="(.+?)" download class='
        href=re.findall(regx,wdata,re.S)[0]
        print "hrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhrefhref",href
        if '1080p' in href.lower():size='1080p'
        elif '720p' in href.lower():size='720'
        elif '480p' in href.lower():size='480p'
        elif '360p' in href.lower():size='360p'
        else:size='???p'
        links.append((size+"__D",href))
    return links
