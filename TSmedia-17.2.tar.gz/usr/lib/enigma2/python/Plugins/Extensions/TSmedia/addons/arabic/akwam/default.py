# -*- coding: utf8 -*-
import urllib,urllib2,re,sys,os,ast,warnings
from tslib import requests
from tslib.requests.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
from iTools import CBaseAddonClass,printD,printE,cleanTitle,getIMDBParams
from akwamAPI import getLinks,HDR
##########################################
#baseurl='https://akwam.cz'
baseurl='https://akwam.to'
def get_geo():
    jsdata=requests.get('https://api.ipify.org/?format=json',verify=False).json()
    my_ip=jsdata['ip']
    jsdata=requests.get('https://api.country.is/%s'%my_ip,verify=False).json()
    my_loc=jsdata['country']
    return my_loc
    
def filterTitle(self,title):
    year=''
    try:
        title=self.removeunicode(title)
        #print "title1",title
        try:year =  re.findall(r'\d+', title)[0]
        except:year=''
        #print "year",year
        title=title.replace(year,'').strip()
        #print "title2",title
        return title,year
    except:
        return title,year
class akwam(CBaseAddonClass):
    def __init__(self,cParam):
        CBaseAddonClass.__init__(self,{'cookie':'akwam.cookie'})
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = baseurl
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        self.cacheLinks  = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
    def showmenu(self):
        self.addDir('SEARCH',baseurl+'/search?q=',103,'img/SEARCH.png','',1,searchall=__file__)
        self.addDir('أفـــلام اجنبية',baseurl+'/movies?section=0&category=0',100,'img/1.png','',1)

        self.addDir('مسلسلات أجنبية',baseurl+'/series?section=30&category=0',200,'img/6.png','',1)

        self.addDir('مسلسلات عربيه',baseurl+'/series?section=29&category=0',200,'img/8.png','',1)
        self.addDir('مسلسلات رمضان 2023',baseurl+'/series?section=0&category=87&year=2023',200,'img/ramadan2023.png','',1)
        self.addDir('مسلسلات رمضان 2022',baseurl+'/series?section=0&category=87&year=2022',200,'img/ramadan2022.png','',1)

        self.addDir('أفــلام عربية',baseurl+'/movies?section=29&category=0',100,'img/7.png','',1)

        self.addDir('1080p',baseurl+'/movies?section=30&quality=1080p',100,'img/2.png','',1)
        self.addDir('720p',baseurl+'/movies?section=30&quality=720p',100,'img/3.png','',1)
        self.addDir('2023',baseurl+'/movies?section=30&year=2023',100,'img/4.png','',1)
        self.addDir('2022',baseurl+'/movies?section=30&year=2022',100,'img/4.png','',1)
        self.addDir('أفــلام هندية',baseurl+'/movies?section=31&category=0',100,'img/9.png','',1)
        self.addDir('مسلسلات هنديه',baseurl+'/series?section=31',200,'img/10.png','',1)
        self.addDir('افلام تركيه',baseurl+'/movies?section=32&category=0',100,'img/11.png','',1)
        self.addDir('مسلسلات تركيه',baseurl+'/series?section=32',200,'img/12.png','',1)
        self.addDir('مسلسلات اسيويه',baseurl+'/series?section=33',200,'img/13.png','',1)
        self.addDir('برامج تلفزيونيه',baseurl+'/shows?section=42',100,'img/14.png','',1)
        self.addDir('البرامج الوثائقيه',baseurl+'/shows?section=46',100,'img/15.png','',1)
        self.addDir('المسرحيات',baseurl+'/shows?section=45',100,'img/16.png','',1)
        self.addDir('المصارعه',baseurl+'/shows?section=43',100,'img/17.png','',1)
        self.addDir('افلام انيمي',baseurl+'/movies?section=0&category=30',100,'img/18.png','',1)
        self.addDir('مسلسلات انيمي',baseurl+'/series?section=0&category=30',200,'img/19.png','',1)
        self.addDir('أفلام اسيوية',baseurl+'/movies?section=33&category=0&rating=0&year=0&language=0&formats=0&quality=0',100,'img/19.png','',1)
        return
    def years(self,url):
        for i in range(2002,2017):                
            return       
    def genres(self,urlmain):
        data=self.getPage(urlmain,cloudflare=True)
        if data is None:
            return
        ##codes
    def getA_Z(self,name='movies'):
        abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
        for letter in abc:
            self.addDir(letter,'/?letter='+letter,100,'',1)
    ###################################movies
    def search(self,name,sterm,page):
        surl=baseurl+'/search?q=%s'%sterm
        if page>1:
            page_url='https://akwam.cz/search/%s/page/%s'%(sterm,str(page))
        else:
            page_url=surl
        print "url_page",page_url
        data=self.getPage(page_url)
        if data is None:
            return
        blocks=data.split('class="entry-image"')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='''href="(.*?)"'''
            href=self.getSM(block,regx)
            regx='''alt="(.*?)"'''
            title=self.getSM(block,regx)
            regx='''data-src="(.*?)"'''                    
            image=self.getSM(block,regx)
            info=''
            regx='''<span class="label rating">.*?></i>(.*?)</span>'''
            rating=self.getSM(block,regx)
            regx='''<span class="label quality">(.*?)</span>'''
            quality=self.getSM(block,regx)
            info=quality+" "+rating
            regx='badge badge-pill badge-secondary ml-1">(.*?)</span>'
            year=self.getSM(block,regx)
            title=title.replace("#039;","")
            if quality and rating:
                info=title+' '+year+" ["+quality+'] '+rating
            else:
                info=title+' '+year     
            title=self.colorize(info)
            if 'serie' in href:
                mode=201
                show='tv'
            else:
                mode=4
                show='movie'
            self.addDir(title,href,mode,image,name,1,True,show=show)
        if len(blocks)>29:
            self.addDir("next page",sterm,103,'img/NEXT.png','',str(page+1),dialog='nosearch')
    def getmovies(self,name,url,page,metaData):
        if page>1:#&page=2
            #https://akwam.cz/movies?section=30&quality=1080p&page=2
            page_url=url+"&page=%s"%str(page) 
        else:
            page_url=url
        #data=self.getPage(page_url)
        data=requests.get(page_url,verify=False).content
        if data is None:
            return
        blocks=data.split('class="entry-image"')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='''href="(.*?)"'''
            href=self.getSM(block,regx)
            regx='''alt="(.*?)"'''
            title=self.getSM(block,regx)
            regx='''data-src="(.*?)"'''                    
            image=self.getSM(block,regx)
            info=''
            regx='''<span class="label rating">.*?></i>(.*?)</span>'''
            rating=self.getSM(block,regx)
            regx='''<span class="label quality">(.*?)</span>'''
            quality=self.getSM(block,regx)
            regx='badge badge-pill badge-secondary ml-1">(.*?)</span>'
            year=self.getSM(block,regx)
            info=quality+" "+rating
            title=title.replace("#039;","")
            #info=title+"("+info+")"
            if quality and rating:
                info=title+' '+year+" ["+quality+'] '+rating
            else:
                info=title+' '+year
            fTitle,year=filterTitle(self,title)
            ###metaData={"name":fTitle,"year":year,"show":'movie'}
            metaData={"name":title,"year":year,"show":'movie'}
            title=self.colorize(info)
            self.addDir(title,href,4,image,name,1,True,show='movie',metaData=metaData)#mode4
        if len(blocks)>29:
            self.addDir("next page",url,100,'img/NEXT.png','',str(page+1))
    ###############################################series
    def getseries(self,name,url,page):
        extra={}
        desc=''
        if page>1:
            #https://akwam.cz/series?section=30&category=0&page=2
            page_url=url+"&page=%s"%str(page) 
        else:
            page_url=url
        #data=self.getPage(page_url)
        data=requests.get(page_url,verify=False).content
        if data is None:
            return
        blocks=data.split('class="entry-image"')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            extra={}
            regx='''href="(.*?)"'''                    
            href=self.getSM(block,regx)
            regx='''alt="(.*?)"'''                    
            title=self.getSM(block,regx)
            regx='''data-src="(.+?)"'''#'''src="(.*?)"'''                    
            image=self.getSM(block,regx)
            #print "image",image
            
            info=''
            regx='''<span class="label rating">.*?></i>(.*?)</span>'''
            rating=self.getSM(block,regx)
            extra['rating']=rating
            regx='''<span class="label quality">(.*?)</span>'''
            quality=self.getSM(block,regx)
            extra['quality']=quality
            info=quality+" "+rating
            title=title.replace("#039;","")
            info=title+"("+info+")"
            title=self.colorize(info)
            #print "extra",extra
            self.addDir(title,href,201,image,name,1,True,extra=extra,show='tv')
        if len(blocks)>23:
            self.addDir("next page",url,200,'img/NEXT.png','',str(page+1))
    def getepisodes(self,name,url,page,image,extra,desc):#mode==201
        #data=self.getPage(url)
        data=requests.get(url,verify=False).content
        print "extra",extra
        extra,desc,img=self.metaData(data=data,extra=extra,desc=desc,image=image,show='tv')
        episodes=data.split('bg-primary2')         
        #print "episodes",episodes
        episodes.pop(0)
        #episodes.reverse()
        for episode in episodes:
            regx='''href="(.*?)"'''                    
            href=self.getSM(episode,regx)
            regx='''class="text-white">(.*?)</a>'''                    
            title=self.getSM(episode,regx)
            regx='''src="(.*?)"'''                    
            image=self.getSM(episode,regx)
            self.addDir(title,href,4,image,name,1,extra=extra,desc=desc,dialog='servers')
        regx='''<a href="(.*?)" class="text-white- ml-2 btn btn-light mb-2">(.*?)</a>'''
        try:seasons=self.getMM(data.split('مواسم اخرى')[1],regx)
        except:return
        print "seasons",seasons
        for href,title in seasons:
            print "href",href
            print "title",title
            self.addDir(title,href,201,image,name,1,extra=extra,desc=desc,dialog='servers')    
    def getservers_movies(self,name,url,page,img,metaData):
        #data=self.getPage(url)
        if metaData.get("imdb_id",'')=='':
            metaData=self.updateMeta(metaData)##change4
	    print "metaData",metaData
        data=requests.get(url,headers=HDR,verify=False).content
        
        if "show-episodes" in data:
            self.addDir(name,url,201,img,name,1,True,show='tv')
        else:
            
            blocks=data.split('class="tab-content quality"')
            i=0
            blocks.pop(0)
            desc=''
            for block in blocks:
                #if 'data-quality="5"' in block:
                if 'data-quality="' in block:
                    regx='<a href="(.*?)"'                  
                    href=self.getSM(block,regx)
            data=requests.get(href.replace("http:","https:"),verify=False).content
            
            regx='<!-- جلب الرابط القديم ارشيف-->(.*?)<div class="ads mb-3 text-center">'
            regx='/watch/(.*?)class="ads'
            data_part=self.getSM(data,regx)
           
            #########################Modified#########################
            blocks2=data_part.split('<a')
            blocks2.pop(0)
            for block_t in blocks2:
                regx='href="(.*?)"'
                srv_url=self.getSM(block_t,regx)
                regx='<br />\n<br />\n\n<a href="(.*?)"'# class="download-link" style="font-size: 20px;color: #a3aaae;">او <span style="color: #ff5e1d;">اضغط هنا</span> للسعودية و باقي الدول المحظورة'
                data_=requests.get(srv_url.replace("http:","https:"),verify=False,allow_redirects=True).content        
                blocks2=data_.split('<source')
                i=0
                blocks2.pop(0)
                desc=''
                for block in blocks2:
                    regx='src="(.*?)"'
                    srv_url=self.getSM(block,regx)
                    regx='size="(.*?)"'
                    qlt=self.getSM(block,regx)
                    if "لمصر" in block_t:
                        self.addDir(name+' ['+qlt+']'+' [EGYPT]', srv_url,0,img,name,1,dialog='servers',desc=desc,metaData=metaData)
                    elif "للسعودية" in block_t:
                        self.addDir(name+' ['+qlt+']'+' [KSA]', srv_url,0,img,name,1,dialog='servers',desc=desc,metaData=metaData)
                        
                    else:
                         self.addDir(name+' ['+qlt+']', srv_url,0,img,name,1,dialog='servers',desc=desc,metaData=metaData)
               # if 'للسعودية و باقي الدول المحظورة' in block:
               #     self.addDir(name+' [KSA]', srv_url,0,img,name,1,dialog='servers',metaData=metaData)
               # else:
               #     self.addDir(name, srv_url,0,img,name,1,dialog='servers',metaData=metaData)
            ############################################################        
                    
        return
    def getservers_series(self,name,url,page,img,extra,desc,show='tv'):
        #data=self.getPage(url)
        data=requests.get(url,verify=False).content
        blocks=data.split('class="col-lg-6 row')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            href=self.getDM(block,'<a href="','" class="link-btn link-show')
            #watch_data=data=self.getPage(href)
            if not "https" in href:href=href.replace('http','https')
            watch_url=self.getPage(href,cloudflare=True)
            hrefs_=self.getDM(watch_url,'<a href="','" class="download-link"')
            Host = hrefs_.split('//')[1]
            Host = Host.split('/')[0]
            Host = Host.split('.')[1]
            hrefs_data=self.getPage(hrefs_.replace(Host,'io'))
            href=self.getDM(hrefs_data,'source src="','"')
            
            self.addDir(name,href,0,img,name,1,dialog='play')    
        '''href=self.getDM(data,'<div class="col-lg-6 col">\n<a href="','" class="link-btn link-show')
        print "WATCH URLxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",href
        watch_data=data=self.getPage(href)
        href=self.getDM(data,'<a href="','" class="download-link"')
        watch_url=self.getPage(href,cloudflare=True)
        href=self.getDM(watch_url,'source src="','"')'''
        
        #extra,desc,image=metaData(self,data,extra,desc)
        #links=getLinks(self,data,url)
        #print "links",links
        #for link in links:
            
        return
    def resolve_host2(self,name,url):
        try:
            stream_url=self.getlinks(url,False)
        except Exception as error:
            print str(error)
            printE()
            return
        server,image,supported=self.getDomain(stream_url)
        if supported== True:
            self.resolvehost(server,stream_url)
        else:self.addDir("link",stream_url,0,"","",1,link=True)
    def resolve_host3(self,name,url):
        server_url = ''
        try:
            server_url=self.getlinks(url,True)
            if "vidtodo" in server_url:print "vidtoduvidtoduvidtoduvidtoduvidtoduvidtoduvidtoduvidtoduvidtoduvidtoduvidtodu=========="
        except Exception as error:
            print str(error)
            printE()
        if "streamz.cc" in server_url:
            print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"
            import requests
            T = requests.Session().get(server_url,verify=False).url
            print "TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT",T
            print "YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY",server_url
            r=self.getPage(T)
            regx = '''o.href = "(.+?)"'''
            data = re.findall(regx,r)
            print "datadatadatadatadatadatadatadatadatadatadata",data
            if data:
                link = data[0]
                exp = "https://streamz.cc/getlink-4c7c04d3e3493cd9dd18cbecb5031469.dll"
                print "=============****************=============****************=============****************",link
                if 'download.dll?c=' in link:link = link.replace('download.dll?c=','getlink-')+".dll"
                else:link = link.replace('download','getlink-')+".dll"
                print link
                self.addDir(name,link,0,"","",1,link=True)
        if "vidtodo" in server_url:
            self.getlinksvidtodu(name,server_url)
        else:self.resolvehost(name,server_url)
    #def getlinks(self,url,    
    def getlinks(self,url,server=False):
        import time
        from CloudflareScraper import CloudflareScraper
        scraper = CloudflareScraper()
        import urllib , json,re
        headers1 = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0'}
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                   'Accept-Encoding': 'gzip, deflate',
                   'Connection': 'keep-alive',
                   'Upgrade-Insecure-Requests': '1'}
        encoded_movie_url=url         
        print "Protected Host = "+encoded_movie_url
        r = scraper.get(encoded_movie_url)
        print "===================================================",r.url
        for c in r.cookies:
            encoded_data=(c.value)
            print "*********************************************************************33333333333333333333333333",encoded_data
        jsondata=urllib.unquote(encoded_data).decode('utf8')
        if "route" in jsondata:
            jsondata2 = json.loads(jsondata)
            Pre_Stream_URL = jsondata2['route']
            Pre_Stream_URL=Pre_Stream_URL.encode("utf-8")
            print "Pre Stream Url================================== ",Pre_Stream_URL
        else:Pre_Stream_URL=encoded_movie_url
        if True:
            if "/download/" in Pre_Stream_URL or "/link/":
                HDR = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                       'Accept': 'application/json, text/javascript, */*; q=0.01',
                       'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                       'Accept-Encoding': 'gzip, deflate',
                       'X-Requested-With': 'XMLHttpRequest',
                       'Connection': 'keep-alive',
                       'Referer': Pre_Stream_URL,
                       'TE': 'Trailers'}
                print "*************************************************_________________download_download",Pre_Stream_URL
                regx = '''"direct_link":"(.+?)"''' 
                r = self.getPage(Pre_Stream_URL,cloudflare=True)
                time.sleep(3)
                hdr = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                       'Accept': 'application/json, text/javascript, */*; q=0.01',
                       'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                       'Accept-Encoding': 'gzip, deflate',
                       'X-Requested-With': 'XMLHttpRequest',
                       'Connection': 'keep-alive',
                       'Referer': url,
                       'Cookie': '__cfduid=daad452515124afdfebcee952fd9a99ce1572701512; prefixakoam_session=a%3A5%3A%7Bs%3A10%3A%22session_id%22%3Bs%3A32%3A%22d480e9b7b30270eac5b601b696b0e704%22%3Bs%3A10%3A%22ip_address%22%3Bs%3A14%3A%22141.101.77.253%22%3Bs%3A10%3A%22user_agent%22%3Bs%3A78%3A%22Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A70.0%29+Gecko%2F20100101+Firefox%2F70.0%22%3Bs%3A13%3A%22last_activity%22%3Bi%3A1572776700%3Bs%3A9%3A%22user_data%22%3Bs%3A0%3A%22%22%3B%7D12f503eb192da973b2c1275c26428d5248ff97bd; _ga=GA1.2.999092258.1572776702; _gid=GA1.2.1278409031.1572776702; _gat_gtag_UA_117929682_1=1',
                       'Content-Length': '0',
                       'TE': 'Trailers'}
                print "Pre_Stream_URL",Pre_Stream_URL
                Pre_Stream_URL=Pre_Stream_URL.replace("/download/","/watching/")
                r = self.getPage(Pre_Stream_URL,cloudflare=True)
                regx='''file: "(.*?)"'''
                link=self.getSM(r,regx)
                print "link",link
                return link
            else:
                print "*************************************************_________________No download_No download",Pre_Stream_URL
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                data=self.getPage(Pre_Stream_URL,cloudflare=True)
                link=re.findall(regx,data, re.M|re.I)[0]
                if link.startswith('//'):link="https:"+link
                print "link",link
                return link
    def getlinksvidtodu(self,name,url):
        params=self.get_params()
        image=params.get("image",None)
        extra=params.get("extra",{})
        try:extra=ast.literal_eval(extra)
        except:extra={}
        import jsunpack
        from CloudflareScraper import CloudflareScraper
        scraper = CloudflareScraper()
        ListVideo = []
        url = url.split('/')[-1]
        url = "https://vidtodu.com/embed-"+str(url)+".html"
        r = scraper.get(url).content
        Rgx = '''<script type='text/javascript'>eval(.+?)</script>'''
        Vid = re.findall(Rgx,r,re.S)
        if Vid:
            data= jsunpack.unpack(Vid[0])
            tmx = '''src:"(.+?)",.+?label:"(.+?)"'''
            Video = re.findall(tmx,data)
            if Video:
                for href,qlt in Video:
                    self.addDir(name+' _'+str(qlt),href,0,image,name,extra=extra,desc='')
            else:
                self.addDir('Ooops_vidtodo ','Error',9,"","",1)
        else:
            self.addDir('Ooops_vidtodo ','Error',9,"","",1)
        return
##########################################################metadata################################
    ##please use in same format 
    def metaData(self,url='',image='',data='',extra={},desc='',show='movie'):#TmX
        if data=='':
            data=self.reqData(url)                
        if show=='tv':
            extra,desc,image=self.metaDataTV(url='',image='',data=data,extra={},desc='')
            return extra,desc,image
        if data=='':
            self.getPage(url)
        regx='''<a href="https://www.imdb.com/title/(.*?)" target="_blank">'''
        imdb_id=self.getSM(data,regx)
        if '/' in imdb_id:
            imdb_id=imdb_id.split('/')[0]
        extra['imdb_id']=imdb_id
        print "imdb_id.",imdb_id
        if imdb_id!='':
            imdbTrailer,imdb_id,videoURL=getIMDBParams(imdb_id=imdb_id)
        else:imdbTrailer=''
        extra['trailer']=imdbTrailer        
        regx='''<div class="text-white"><p>(.*?)</p></div>'''
        regx2='''<span style="color:#FFD700">.*?</span>(.*?)<br'''
        desc=self.getSM(data,regx)
        if desc=='':
            desc=self.getSM(data,regx2)
        desc=self.cleanhtml(desc)
        regx = '''<div class="font-size-16 text-white mt-2"><span>(.+?)</span>'''#country,year,duration
        match=self.getMM(data,regx)
        print "match",match
        try:
            extra['language'] = match[0]
            extra['translation'] = match[1]
            extra['country'] = match[2]
            extra['year'] = match[3]
            ###extra['duration'] = match[4]
        except:
            printE()
        regx='''class="badge badge-pill badge-light ml-2">(.+?)</a>'''
        extra['genres']=self.getMM(data,regx)
        regx='''<span>جودة الفيلم :(.+?)</span>'''
        if extra.get('quality','')=='':
            extra['quality']=self.getSM(data,regx)
        regx='''<span class="mx-2">(.+?)</span>'''
        if extra.get('rating','')=='':
            extra['rating']=self.getSM(data,regx)
        regx='''<span class="badge.+?"(.+?)</span>'''
        extra['pg']=self.getSM(data,regx)
        regx='''<picture><img src="(.+?)" class="img-fluid"'''
        image=self.getSM(data,regx)
        return extra,desc,image
    def metaDataTV(self,url='',image='',data='',extra={},desc=''):
        if data=='':
            self.getPage(url)
        regx='''<a href="https://www.imdb.com/title/(.*?)" target="_blank">'''
        imdb_id=self.getSM(data,regx)
        if '/?' in imdb_id:
            imdb_id=imdb_id.split('/?')[0]
        extra['imdb_id']=imdb_id
        print "imdb_id.",imdb_id
        regx='''<div class="text-white"><p>(.*?)</p></div>'''
        regx2='''<span style="color:#FFD700">.*?</span>(.*?)<br'''
        desc=self.getSM(data,regx)
        if desc=='':
            desc=self.getSM(data,regx2)
        desc=self.cleanhtml(desc)
        regx = '''<div class="font-size-16 text-white mt-2"><span>(.+?)</span>'''#country,year,duration
        match=self.getMM(data,regx)
        print "match",match
        try:
            extra['language'] = match[0]
            extra['translation'] = match[1]
            extra['country'] = match[2]
            extra['year'] = match[3]
            extra['duration'] = match[4]
        except:
            printE()
        regx='''class="badge badge-pill badge-light ml-2">(.+?)</a>'''
        extra['genres']=self.getMM(data,regx)
        regx='''<span>جودة الفيلم :(.+?)</span>'''
        if extra.get('quality','')=='':
            extra['quality']=self.getSM(data,regx)
        regx='''<span class="mx-2">(.+?)</span>'''
        if extra.get('rating','')=='':
            extra['rating']=self.getSM(data,regx)
        regx='''<span class="badge.+?"(.+?)</span>'''
        extra['pg']=self.getSM(data,regx)
        regx='''<a href="https://www.youtube.com/channel/(.+?)" target="_blank" class="youtube mx-2">'''
        extra['youtube']=self.getSM(data,regx)
        regx='''<picture><img src="(.+?)" class="img-fluid"'''
        image=self.getSM(data,regx)
        return extra,desc,image
#######################################################################################################
    def run(self,params=None):
        try:
            url=None
            name=None
            mode=None
            page=1
            name=params.get("name",None)
            url=params.get("url",None)
            try:mode=int(params.get("mode",None))
            except:mode=None
            image=params.get("image",None)
            section=params.get("section",None)
            page=int(params.get("page",1))
            extra=params.get("extra",{})
            print "extra111",extra
            desc=params.get("desc",{})
            show=params.get("show",None)
            metaData=params.get("metaData",{})
            printD("module params",params)
            print "Mode1: "+str(mode)
            print "URL: "+str(url)
            print "Name: "+str(name)
            print "Image: "+str(image)
            print "page: "+str(page)
            print "section: "+str(section)
            print "show: "+str(show)
            print "extra: "+str(extra)
            if mode==None or url==None or len(url)<1:
                print ""
                self.showmenu()
            elif mode==1:
                print ""+url
                self.getservers_series(name,url,page,image,extra,desc,show)
            elif mode==2:
                print ""+url
                self.resolve_host2(name,url)
            elif mode==3:
                print ""+url
                self.resolve_host3(name,url)
            elif mode==4:
                print ""+url
                self.getservers_movies(name,url,page,image,metaData)
            elif mode==9:
                pass
            elif mode==100:
                print "ok1"+url
                self.getmovies(name,url,page,metaData)
            elif mode==101:
                print ""+url
                self.getgenre('movies')
            elif mode==102:
                print ""+url
                self.getA_Z('movies')
            elif mode==103:
                sterm = self.getsearchtext()
                self.search("Search",sterm,page)
            elif mode==200:
                self.getseries(name,url,page)
            elif mode==201:
                self.getepisodes(name,url,page,image,extra,desc)
            elif mode==203:
                print ""+url
                self.search_tvshows(url)
            return self.endDir()
        except:
            printE()
        return []
def start(params=None):
    addon=akwam(params)
    return addon.run(params)
