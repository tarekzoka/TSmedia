#!/usr/bin/python
# -*- coding: utf-8 -*- 
import sys
import urllib,urllib2,re,os,ast
from hosts.tstls import *
from iTools import CBaseAddonClass,printD,printE,getIMDBParams
os_platform=sys.platform
extra={}
base_url='https://wecima.tube'
##########################################parsing tools
def filterTitle(self,title):
    year=''
    try:
        title=self.removeunicode(title)
        #print "title1",title
        try:year =  re.findall(r'\d+', title)[0]
        except:year=''
        #print "year",year
        title=title.replace(year,'').strip()
        title=title.replace('مترجم','').strip()
        title=title.replace('مشاهدة فيلم','').strip()
        title=title.replace('فيلم','').strip()
        #print "title2",title
        return title,year
    except:
        return title,year
class mycima(CBaseAddonClass):
    def __init__(self,cParams={}):
        CBaseAddonClass.__init__(self,{'cookie':'mycima.cookie','module_path':__file__})
        self.cParams=cParams
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = base_url
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        self.cacheLinks  = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
        self.module_path=__file__
    def showmenu(self):
        baseurl=self.getMainUrl()
        self.addDir('search',base_url+"/?s=",103,'img/search.png','',1,searchall=True)
        self.addDir('افلام اجنبية',base_url+'/category/افلام/10-movies-english-افلام-اجنبي/',100,'img/1.png','',1)
        self.addDir('افلام عربى',base_url+'/category/افلام/6-arabic-movies-افلام-عربي/',100,'img/2.png','',1)
        self.addDir('افلام هندى',base_url+'/category/افلام/افلام-هندي-indian-movies/',100,'img/3.png','',1)
        self.addDir('افلام تركى',base_url+'/category/افلام/افلام-تركى-turkish-films/',100,'img/5.png','',1)
        self.addDir('افلام ثائقية',base_url+'/category/افلام/افلام-وثائقية-documentary-films/',100,'img/5.png','',1)
        self.addDir('افلام كرتون',base_url+'/category/افلام-كرتون/',100,'img/5.png','',1)
        self.addDir('مسلسلات وثائقية',base_url+'/category/مسلسلات/مسلسلات-وثائقية-documentary-series/',100,'img/6.png','',1)
        self.addDir('مسلسلات اجنبي',base_url+'/category/مسلسلات/5-series-english-مسلسلات-اجنبي/',200,'img/12.png','',1)
        self.addDir('مسلسلات عربية',base_url+'/category/مسلسلات/13-مسلسلات-عربيه-arabic-series/',200,'img/7.png','',1)
        self.addDir('مسلسلات رمضان 2023',base_url+'/category/مسلسلات/مسلسلات-رمضان-2023-series-ramadan-2023/',200,'img/7.png','',1)
        self.addDir('مسلسلات رمضان 2022',base_url+'/category/مسلسلات/مسلسلات-رمضان-2022/',200,'img/7.png','',1)
        self.addDir('مسلسلات تركية',base_url+'/category/مسلسلات/8-مسلسلات-تركية-turkish-series/',200,'img/8.png','',1)
        self.addDir('مسلسلات اسيوية',base_url+'/category/مسلسلات/مسلسلات-اسيوية/',200,'img/11.png','',1)
        self.addDir('مسلسلات هندية',base_url+'/category/مسلسلات/9-series-indian-مسلسلات-هندية/',200,'img/13.png','',1)
        self.addDir('مسلسلات كرتون',base_url+'/category/مسلسلات-كرتون/',200,'img/13.png','',1)
        #self.addDir('مسلسلات رمضان 2021',base_url+'/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/5-%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b1%d9%85%d8%b6%d8%a7%d9%86-ramadan-2021/',200,'img/15.png','',1)
        self.addDir('شركات الإنتاج','',110,'img/prod_cm.png','',1)                   
 
     
    def search_103(self,name,sterm,page):
        surl=base_url+'/search/%s'%sterm
        data=self.getPage(surl)
        if data is None:
            return
        blocks=data.split('<div class="Thumb--GridItem">')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            #link
            extra={}
            block='<a title="'+block
            regx='''href="(.*?)"'''                    
            href=self.getSM(block,regx)
            regx='''class="hasyear">(.+?)class="PostItemStats">'''
            title=self.getSM(block,regx)
            if '<ul' in title:
                title=title.split('<ul')[0]
            title=title.replace('الرقابة على المشاهد','')
            regx='''url\((.+?)\);'''
            image=self.getSM(block,regx)
            print "href= ",href
            print "title= ",title
            print "image= ",image
            print "================================================"
            info=''
            title=self.cleanhtml(title)
            title=title.replace('N/a','')
            self.colorize(title,'red')    
            if 'مسلسل' in title or '/series/' in href:
                mode=201
                show='tv'
            else:
                show='movie'
                mode=1
            self.addDir(title,href,mode,image,name,1,True,extra=extra,show=show)
    def getmovies(self,name,url,page,metaData):
        if page>1:
            url_page=url+"page/%s/"%str(page) 
        else:
            url_page=url
        print "url_page",url_page
        data=self.getPage(url_page)
        items=data.split('class="Thumb--GridItem">')
        blocks=items
        if data is None:
            return
        i=0
        print "blocks",len(items)
        blocks.pop(0)
        for block in blocks:
            #link
            extra={}
            regx='''href="(.+?)"'''
            href=self.getSM(block,regx)
            #print href
            regx='title="(.*?)"'
            title=self.getSM(block,regx)#background-image:url((.+?));"
            #regx='''"background.+?url\((.+?)\);">'''
            #image=self.getSM(block,regx)
            regx='image:url(.*?);'
            image=self.getSM(block,regx).replace('(','').replace(')','')
            if "https:" in image:pass
            else:image="https:"+image
            info=''
            #year
            regx='''<span class="year">(.+?)</span>'''
            year=self.getSM(block,regx)
            if year !='':
                year=year.replace("(",'').replace(")","")
                info=year
                extra['rating']=year
            title=self.cleanhtml(title)
            title=title.replace('N/a','').replace('مشاهدة فيلم ','')
            fTitle,year=filterTitle(self,title)
            metaData={"name":fTitle,"year":year,"show":'movie'}
            if info!='':    
                title=title+"("+info+")"
                title=title.replace('N/a','')
            self.colorize(title,'green')    
            self.addDir(title,href,1,image,name,1,True,metaData=metaData,show='movie')
        if len(blocks)>35:
            self.addDir("next page",url,100,'/img/next.png','',str(page+1))
    def getseries(self,name,url,page):##series
        if page>1:#/page/2/
            url_page=url+"page/%s/"%str(page) 
        else:
            url_page=url

        data=self.getPage(url_page)
        if data is None:
            return
        blocks=data.split('class="Thumb--GridItem">')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            #link
            extra={}
            regx='''href="(.+?)"'''
            href=self.getSM(block,regx)
            regx='title="(.+?)"'
            title=self.getSM(block,regx)
            #print "title 111111111============== ",title
            #if title == '':
            #    title=self.getSM(block,'<strong dir="auto">(.+?)</strong>')
            #    print "title 222222222============== ",title
            ###regx='''"background.+?url\((.+?)\);">'''
            regx="--image:url(.*?);"
            image=self.getSM(block,regx).replace('(','').replace(')','')
            info=''
            #year
            regx='''<span class="year">(.+?)</span>'''
            year=self.getSM(block,regx)
            if year !='':
                year=year.replace("(",'').replace(")","")
                info=year
                extra['rating']=year
            title=self.cleanhtml(title)
            title=title.replace('مشاهدة مسلسل','').replace('مسلسل','').replace('المسلسل','')
            if info!='':    
                title=title+"("+info+")"
                title=title.replace('N/a','')
            self.colorize(title,'blue')    
            self.addDir(title,href,201,image,name,1,True,extra=extra,show='tv')
        if len(blocks)>35:
            self.addDir("next page",url,200,'/img/next.png','',str(page+1))
            
    def getseasons(self,name,url,page,image,metaData):##series
        print "**************************************************-------------------------------------------------------"
        data=self.getPage(url)
        if data is None:
            return
        #regx='''<a href="(.+?)"><i class="ion ion-ios-arrow-back"></i>(.+?)</a>'''
        self.addDir(name,url,1,image,name,show='tv',metaData=metaData)
        seasons_data=self.getDM(data,'class="List--Seasons--Episodes">','class="Episodes--Seasons--Episodes">')
        blocks=seasons_data.split('class="hoverable activable"')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            season      =   self.getDM(block,'">','</a>')
            season_href =   self.getDM(block,'href="','"')
            if 'class="selected"' in data:
                metaData['multi_seasons']='True'
            else:
                metaData['multi_seasons']='False'
            self.addDir(season,season_href,202,image,name,1,metaData=metaData)
        if 'class="selected"' in seasons_data:
            ss_selected        =     self.getDM(seasons_data,'class="selected"','</div>')
            print "SELECTEDxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:",ss_selected
            ss_selected_href   =     self.getDM(ss_selected,'href="','"')
            ss_selected_season =     self.getDM(ss_selected,'">','</a>')
            metaData['multi_seasons']='True'
            self.addDir(ss_selected_season,ss_selected_href,202,image,name,1,metaData=metaData)
        else:
            metaData['multi_seasons']='False'
            single_season_href=self.getDM(data,'class="Series--Section"><a href="','"')
            self.addDir('حلقات أخرى',single_season_href,202,image,name,1,metaData=metaData)
        '''seasons=self.getMM(data,regx)
        #print "====================================seasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasonsseasons",seasons
        if seasons:
            seasons.pop(0)
            seasons.pop(0)
            for href,title in seasons:
                print "----------------------",href
                print "----------------------",title
                self.addDir(title.encode('utf-8'),href,202,image,name,1)
        else:
            self.getservers_1(name,url,image,'','',show='tv')'''
    def getepisodes(self,name,url,page,image,metaData):
        regx='/series/(.*?)/'
        serie_id=self.getSM(url,regx)
        
        if page>1:#/page/2/
            url_page=base_url+"/AjaxCenter/MoreEpisodes/%s/%s/"%(serie_id,str(page)) 
        else:
            url_page=url

        data=self.getPage(url_page)
        
        if metaData['multi_seasons']=='True':
            eps_data=self.getDM(data,'class="Episodes--Seasons--Episodes">','<singlesections>')
        else:
            eps_data=self.getDM(data,'class="Episodes--Seasons--Episodes Full--Width">','<singlesections>')
        
        blocks=eps_data.split('class="hoverable activable"')
        i=0
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
                           
            ep_href     =   self.getDM(block,'href="','"')
            ep_title    =   self.getDM(block,'<episodeTitle>','</episodeTitle>')
            self.addDir(ep_title,ep_href,1,image,name,1,True,show='tv',dialog='servers')
        ###if len(blocks)>58:
        ###    self.addDir("next page",url,202,'/img/next.png','',str(page+39))    
            
    def get_productions_list(self,name,url,page):
        self.addDir('NetFlix Movies',base_url+'/production/netflix/',100,'img/netflix.png','',1)
        self.addDir('NetFlix Series',base_url+'/production/netflix/list/',200,'img/netflix.png','',1)
        self.addDir('Warner-Bros Movies',base_url+'/production/warner-bros/',100,'img/warner_bros.png','',1)
        self.addDir('Warner-Bros Series',base_url+'/production/warner-bros/list/',200,'img/warner_bros.png','',1)
        self.addDir('Lionsgate Movies',base_url+'/production/lionsgate/',100,'img/lionsgate.png','',1)
        self.addDir('Lionsgate Series',base_url+'/production/lionsgate/list/',200,'img/lionsgate.png','',1)
        self.addDir('Walt-Disney Movies',base_url+'/production/walt-disney-pictures/',100,'img/walt_disney.png','',1)
        self.addDir('Universal Movies',base_url+'/production/universal-pictures/',100,'img/universal.png','',1)
    def postdatatos(self,url):
        data=self.getPage(url)
        Rgx = '''<li  data-source="(.+?)" data-server'''
        cline = re.findall(Rgx,data)
        return cline
    def getservers_1(self,name,url,image,desc,metaData,show):
        data=self.getPage(url)
        #printD("input-meta",metaData)
        if metaData.get("imdb_id",'')=="":
            metaData=self.updateMeta(metaData)
            printD("output-meta",metaData)
        
        blocks=data.split('<btn data')
        print "blocks",len(blocks)
        blocks.pop(0)
        for block in blocks:
            regx='<strong>(.*?)</strong>'
            server=self.getSM(block,regx)   
            regx='-url="(.*?)"'
            server_url=self.getSM(block,regx)
            server_url=str.join(" ", server_url.splitlines()).replace(' ', '')
            self.addDir(name +' ['+server+']',server_url,2,image,name,metaData=metaData,desc=desc,dialog='servers')
        regx='class="List--Download--Wecima--Single">(.*?)</div>'
        dnld_srv=self.getSM(data,regx)
        blocks2=dnld_srv.split('target="_blank"')
        print "blocks",len(blocks)
        blocks2.pop(0)
        for block2 in blocks2:
            regx='"></i>(.*?)</resolution>'
            server=self.getSM(block2,regx)   
            regx='href="(.*?)"'
            server_url=self.getSM(block2,regx)
            print "SRV:",server
            #server_url=str.join(" ", server_url.splitlines()).replace(' ', '')
            self.addDir(name +' ['+server+' DIRECT]',server_url,0,image,name,metaData=metaData,desc=desc,dialog='servers')
        return
    def resolve_Mycima(self,url):
        data=self.getPage(url)
        rgx = '''<source src="(.+?)"'''
        _T = re.findall(rgx,data)
        if _T:
            return _T[0]
        else:return 'Nda'
    def resolve_host(self,name,url):

        if os_platform=="win32" or os_platform=="win64":
            u_referer = ' :http-referrer="'+url+'"'
        else:
            u_referer= '#Referer='+url
        Host = url.split('//')[1]
        Host = Host.split('/')[0]
        print '***********************************************************************************************************************************************************************',Host
        if "vidbam" in url or "vidbom" in url or "vadbam" in url:
            stream_url=get_vidbam_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "vidshar" in url or "viidshar" in url:
            stream_url=get_vidsharorg_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "uqload" in url:
            stream_url = get_uqload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif 'uptobox' in url or 'uptostream' in url:
            stream_url=get_uptoboxstream_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "goved" in url or "govad" in url:
            stream_url=get_goved_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "userload" in url:
            stream_url=get_userload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
        elif "dood" in url:
            stream_url=get_doodstream_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "myviid" in url:
            stream_url=get_myviid_srvx(url)
            self.addDir(name,stream_url,0,'',name,1)
        elif "userload.co" in url:
            stream_url=get_userload_srvx(url)
            self.addDir(name,stream_url+u_referer,0,'',name,1)
            
        elif "vidia.tv" in url:
            print "333333333333333333333333333333333333333"
            from pamicym import get_vidia_tv
            link = get_vidia_tv(url)
            if link != "nada":
                self.addDir(name,link,0,"",name,1,desc='',extra={})
            return
        elif "/run/" in url:
            print "44444444444444444444444444444444444444444444"
            from pamicym import get_mycima_me
            link = get_mycima_me(url)
            if link != "nada":
                self.addDir(name,link,0,"",name,1,desc='',extra={})
            return
        else:
            print "5555555555555555555555555555555555555555555"
            self.resolvehost(name,url)
##########################################################metadata################################
    ##please use in same format 
    def metaData(self,url='',image='',data='',extra={},desc='',show='movie'):#TmX
        if data=='':
            data=self.getPage(url)                
        params=['rating','quality','country','language','genres','trailer','image','desc']
        if 'rating' in params:    
            regx='''<div class="IMDBRatio"><span>(.+?)</span><em>IMDb</em>'''
            extra['rating']=self.getSM(data,regx)
        if 'quality' in params:
            regx='''<span>الجودة</span><p><a href=".+?"><span.+?></span>(.+?)</a></p></li>'''
            extra['quality']=self.getSM(data,regx)
        if 'year' in params:
            regx='''<span>سنة الاصدار:</span><a class="popBeforeGo" href=".+?">(.+?)</a>'''
            extra['year']=self.getSM(data,regx)
        ######country
        if 'country' in params:
            regx='''<span>البلد و اللغة</span><p><a href=".+?">(.+?)</a>'''
            extra['country']=self.getSM(data,regx)
        if 'language' in params:
            regx='''<em></em><a href=".+?">(.+?)</a>'''
            language=self.getSM(data,regx)
            extra['language']=self.cleanhtml(language)
        if 'duration' in params:    
            regx='''<span>البلد و اللغة</span><p dir="auto"><a class="unline".+?">(.+?)</a><em>'''
            extra['duration']=self.getSM(data,regx)
        if 'pg' in params:
            pg=self.getDM(data,'التصنيف</td>','</tr>',False)
            extra['pg']=self.cleanhtml(pg)
        if 'genres' in params:
            regx='''<span>النوع</span><p><a href=".+?">(.+?)</a>'''
            genres=self.getSM(data,regx)
            extra['genres']=self.cleanhtml(genres,withSpace=True)
        if 'trailer' in params:   
            regx='''<iframe allowfullscreen name="trailer" src="" data-ifr="(.+?)".+?></iframe>'''
            trailer=self.getSM(data,regx)
            print 'trailer',trailer
            if 'imdb.com' in trailer:
                print 'trailer2',trailer
                imdbTrailer,imdb_id,videoURL=getIMDBParams(imdbTrailer=trailer,imdb_id='')
                extra['imdb_id']=imdb_id
                print "imdb_id",imdb_id                    
            extra['trailer']=trailer        
        if 'image' in params:
            regx='''<img class="imgLoader" data-img="(.+?)" alt=".+?" />'''
            image=self.getSM(data,regx)
        if 'desc' in params:
            regx='''<div class="StoryMovieContent">(.+?)<br>'''
            desc=self.getSM(data,regx)
            desc=self.cleanhtml(desc)
        return extra,desc,image
    def metaDataTV(self,url='',image='',data='',extra={},desc=''):
        if data=='':
            data=self.getPage(url)
        params=['rating','quality','country','language','genres','trailer','image','desc']
        if 'rating' in params:    
            regx='''<span>التقييم:</span><strong><a href="https://tuktukcinema.com/rate">(.+?)</a>'''
            extra['rating']=self.getSM(data,regx)
        if 'quality' in params:
            regx='''<span>الجودة</span><p><a href=".+?"><span.+?></span>(.+?)</a></p></li>'''
            extra['quality']=self.getSM(data,regx)
        if 'year' in params:
            regx='''<span>سنة الاصدار:</span><a class="popBeforeGo" href=".+?">(.+?)</a>'''
            extra['year']=self.getSM(data,regx)
        ######country
        if 'country' in params:
            regx='''<span>البلد و اللغة</span><p><a href=".+?">(.+?)</a>'''
            extra['country']=self.getSM(data,regx)
        if 'language' in params:
            regx='''<em></em><a href=".+?">(.+?)</a>'''
            language=self.getSM(data,regx)
            extra['language']=self.cleanhtml(language)
        if 'duration' in params:    
            regx='''</div><span>مدة العرض:</span><strong>(.+?)</strong></li>'''
            extra['duration']=self.getSM(data,regx)
        if 'pg' in params:
            pg=self.getDM(data,'التصنيف</td>','</tr>',False)
            extra['pg']=self.cleanhtml(pg)
        if 'genres' in params:
            regx='''<span>النوع</span><p><a href=".+?">(.+?)</a>'''
            genres=self.getSM(data,regx)
            extra['genres']=self.cleanhtml(genres,withSpace=True)
        if 'trailer' in params:   
            regx='''<iframe allowfullscreen name="trailer" src="" data-ifr="(.+?)".+?></iframe>'''
            trailer=self.getSM(data,regx)
            print 'trailer',trailer
            if 'imdb.com' in trailer:
                print 'trailer2',trailer
                return
                imdbTrailer,imdb_id,videoURL=getIMDBParams(imdbTrailer=trailer,imdb_id='')
                extra['imdb_id']=imdb_id
                print "imdb_id",imdb_id
            extra['trailer']=trailer
        if 'image' in params:
            regx='''<img class="imgLoader" data-img="(.+?)" alt=".+?" />'''
            image=self.getSM(data,regx)
        if 'desc' in params:
            regx='''<div class="StoryMovieContent"><br>(.+?)</div>'''
            desc=self.getSM(data,regx)
            desc=self.cleanhtml(desc)
        return extra,desc,image
#######################################################################################################
    def run(self,cParams):
        self.cParams=cParams
        if cParams is None:
            self.cParams=self.get_params()
        url=self.cParams.get('url','')
        name=self.cParams.get('name','')
        try:mode=int(self.cParams.get('mode',None))
        except:mode=None
        page=int(self.cParams.get('page',1))
        category=self.cParams.get('category','')
        extra=self.cParams.get("extra",{})
        try:extra=ast.literal_eval(extra)
        except:pass
        desc=self.cParams.get("desc",'')
        show=self.cParams.get('show','')
        metaData=cParams.get("metaData",{})
        image=self.cParams.get('image','')
        sterm=self.cParams.get('sterm','')
        print "Mode: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "sterm: "+str(sterm)
        print "page: "+str(page)
        print "cacategory: "+category.encode("utf-8","replace")
        print "extra: "+str(extra)
        print "show: "+str(show)
        print "image: "+str(image.encode("utf-8","ignore"))
        if mode==None:
            print ""
            self.showmenu()
        elif mode==1:
            print ""+url
            self.getservers_1(name,url,image,desc,metaData,show)
        elif mode==2:
            print ""+url
            self.resolve_host(name,url)
        elif mode==100:
            print ""+url
            self.getmovies(name,url,page,metaData)
        elif mode==103:
            if sterm.strip()=='':
                sterm = self.getsearchtext()
            self.search_103("Search",sterm,page)
        elif mode==110:
            self.get_productions_list(name,url,page)
        elif mode==200:
            self.getseries(name,url,page)
        elif mode==201:
            self.getseasons(name,url,page,image,metaData)
        elif mode==202:
            self.getepisodes(name,url,page,image,metaData)
        return self.endDir()
def start(cParams=None):
    addon=mycima(cParams)
    addon._iniAddon()
    return addon.run(cParams)

