#!/usr/bin/python
# -*- coding: utf-8 -*-
import re,requests
url = 'https://mycima.video'
menulist = []
hdr = {'Host': 'mycima.video',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
'Accept-Encoding': 'gzip, deflate',
'Connection': 'keep-alive',
'Upgrade-Insecure-Requests': '1'}
data = requests.get(url,headers=hdr,verify=False).content
rgx = 'class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item.+?<a href="(.+?)">(.+?)</a></li>'
mycima = re.findall(rgx,data)
for href,title in mycima:
    title = title.decode('utf-8')
    print href
    print title
    menulist.append((href,title))
    print "======================"
print menulist
