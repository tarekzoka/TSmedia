from jsunpack import unpack
import re,json
import requests
from string import find
Sng = requests.Session()
def postData(url):
    Listo = []
    _r = Sng.get(url,verify=False).content
    Rgx = '''</back></li><li><a href="(.+?)" class="nobind"><i style'''
    tmx = '''<li class="MyCimaServer active"><a href="(.+?)" class="nobind"><span>M</span>'''
    nobind = re.findall(Rgx, _r)
    active = re.findall(tmx, _r)
    MyList =active+nobind
    print "clineclineclineclineclineclinecline==================",MyList
    return MyList
def get_mycima_vip(url):
    print "=====================================================================================pppppppppppppppppppppppppp"
    hdr={'Host': 'w.mycima.vip',
         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
         'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
         'Accept-Encoding': 'gzip, deflate',
         'Connection': 'keep-alive',
         'Upgrade-Insecure-Requests': '1',
         'Pragma': 'no-cache',
         'Cache-Control': 'no-cache'}
    _r = Sng.get(url,headers=hdr,verify=False).content
    Rgx = '''<source src="(.+?)"'''
    source = re.findall(Rgx,_r)
    print "sourcesourcesourcesourcesourcesourcesourcesourcesourcesourcesourcesourcesourcesourcesource",source
    if source:
        return source[0]
    else:
        return "nada"
def get_mycima_cloud(url):
    hdr={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
         'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
         'Sec-Fetch-Dest':'iframe',
         'Sec-Fetch-Mode':'navigate',
         'TE':'trailers',
         'Accept-Encoding': 'gzip, deflate'}
    data = requests.get(url,headers=hdr,verify=False,allow_redirects=True).content
    regx = 'player.qualityselector\((.*?)formats:'
    try:jsd=re.findall( regx , data , flags=re.DOTALL )
    except:pass
    jsdata=''.join(jsd)
    return jsdata
def get_packed_data(html):
    packed_data = ''
    for match in re.finditer('(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            js_data = unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass
    return packed_data
def get_vidia_tv(url):
    _r = Sng.get(url,verify=False).content
    _r2 = get_packed_data(_r)
    print "*******************************************************************************",_r2
    Rgx = '''\{sources:\[\{file:".+?"\},\{file:"(.+?)",label:""\}'''#'''"http(.+?).m3u8"'''
    source = re.findall(Rgx,_r2)
    if source:
        return source[0]
    else:
        return "nada"
def get_Host(url):
    host = url.split('//')[1]
    host = host.split('/')[0]
    return host
def get_mycima_me(url):
    host=get_Host(url)
    hdr = {'Host': host,#'mycima.video',
           'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    _r = Sng.get(url,headers=hdr,verify=False).content
    Rgx = '''<source src="(.+?)"'''
    source = re.findall(Rgx,_r)
    if source:
        return source[0]
    else:
        return "nada"

    
page='https://mycima.cloud/run/39a8dafa3a7c65ffeb1f82ed4784594c78727970b6a1fbd30ad5a13827c4a185097d0a3c5fcf711f9a8b3fbe46a2f2c7d6028a49d370c9247d7a37bd00125a62b9c674d94d6b8b8eeda8e7e7bec698a73b1e67d2b5feecea604a6e06ce965cc9b2ef09/?Key=iRHIKsh3WioewXSWoHsAMQ&Expires=1653841962'
print get_mycima_cloud(page)
