import requests,re,json
T = requests.Session()
def get_video_url(url):
    ListVideo = []
    Id = url.split('/')[-1]
    link = "https://www.core1player.com/api/source/"+Id
    print link
    prm = {"r": "","d": "www.core1player.com"}
    _r = requests.post(link).json()
    _data= _r['data']
    if _data:
        for keys in _data:
            hrefs = keys['file']
            qlt = keys['label']
            _C1 = requests.head(hrefs, allow_redirects=True)
            print hrefs
            print _C1.url
            print "==============================================="
            w = ('Cool_core1player [ '+str(qlt)+' ]',_C1.url)
            ListVideo.append(w)
    else:
        w = ('Ooops_core1player','http://Error')
        ListVideo.append(w)
    return ListVideo
def testLink():
    url = 'https://www.core1player.com/v/rjdxpfeded24egj'
    links = get_video_url(url)
    print 'links',links












if __name__=='__main__':
     
     url0='https://www.core1player.com/v/rjdxpfeded24egj'
     print get_video_url(url0)