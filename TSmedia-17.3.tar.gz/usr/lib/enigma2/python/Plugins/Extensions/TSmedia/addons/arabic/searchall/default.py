import sys, re, os, time

from iTools import CBaseAddonClass, Addon,AppPath,printE,printD 
#####
os_platform = sys.platform
##informtion about addon path
addonPath=os.path.dirname(os.path.abspath(__file__))
addonID=os.path.split(addonPath)[-1]
addonSectionPath=os.path.split(addonPath)[-2]
sectionID=os.path.split(addonSectionPath)[-1]
addonSPath=sectionID+"/"+addonID
##############################
###################################################
from TSmediaThreads import  dataThread



class searchall(CBaseAddonClass):

    def __init__(self, params={}):
       
        CBaseAddonClass.__init__(self, {'cookie': 'searchall.cookie'})
        self.cParams = params
        printD('self.cParams555t',self.cParams)
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = 'https://searchall'
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}

        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        self.cacheLinks  = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
      


    def searchAll(self,name,sterm,page):
            addonsSA=self.cParams.get('addonsSA',[])
            params = ''
            i = 0
            print 'addonSectionPath',addonSectionPath
            cParamsList = []
            self.threadsCounter=0
            self.threadsRunning=True
            self.threadsCount=0
            self.retList=[]
            self.addon_ids=[]
            cParamsList=[]
            self.totalCount=0
            sys.path.append(AppPath+"/addons")
            
            if addonsSA!=[]:
               printD("saddonsSA-count",len(addonsSA)) 
               for laddon_id in addonsSA:
                       section_id,addon_id=laddon_id.split("/")
                       self.threadsCount=self.threadsCount+1
                       cParams={"caddon_id":addon_id,
                                "csection_id":sectionID,
                                "url":"http://%s"%laddon_id,
                                "name":"search",
                                "page":1,
                                "mode":103,"sterm":sterm}
                       cParamsList.append(cParams)
                       
            else:
               for sdir in os.listdir(addonSectionPath):
                    addon_path = os.path.join(addonSectionPath, sdir)
                    if os.path.isdir(addon_path):
                        paramsFile=addon_path+"/params"
                        params = Addon(sectionID+"/"+sdir).readParams(paramsFile)
                        searchAll=params.get("searchall",False)
                         
                        if searchAll:
                           print "addon",sdir
                           self.addon_ids.append(sdir)
                           self.threadsCount=self.threadsCount+1
                           cParams={"caddon_id":sdir,
                                    "csection_id":sectionID,
                                    "url":"",
                                    "name":"search",
                                    "page":1,
                                    "mode":103,"sterm":sterm}
                           cParamsList.append(cParams)
                       
            for item in cParamsList:
               
               self.searchAddon(item)

            while self.threadsRunning:
                          time.sleep(1)
                          # printD("self.threadsCounter",self.threadsCounter)
                          #pass
            printD("threads completed")
            
            
            printD("self.retlist-count",len(self.retList))
            fcount=str(len(self.retList))
            totalResults=0
            for item in self.retList:
              extra={}
              addon_id=item[0]
              image=addonSectionPath+"/"+addon_id+"/icon.png"
              
              extra['datalist']=item[1]
              foundResults=len(item[1])
               
              
              title=str(addon_id)+"("+str(foundResults)+")"
              
              title=self.colorize(title)
              try:self.addDir(title,str(addon_id),105,image,"        %s results found for %s"%(str(self.totalCount),sterm),1,extra=extra)
              except:continue
             
            
    def searchAddon(self,cParams):
            try:
                
                addon_id=cParams.get("caddon_id","")
                
                imStatement="from "+ sectionID.lower()+"."+addon_id +".default import start"
                printD('imStatement',imStatement)
                exec imStatement
            except:
                  #self.threadsCount=self.threadsCount-1
                  printD("self.threadsCounter-error-new",self.threadsCounter)
                  printE()
                  self.publish(retList=[],addon_id=addon_id+"-error")
                  return
           
            try:
                printD('dataThread started...', '')
                self.dataThread = dataThread(start, cParams, self.publish)
                self.dataThread.daemon = True
                self.dataThread.start()
            
            except:
                self.threadsCount=self.threadsCount-1
                printD("self.threadsCounter-error-new2",self.threadsCounter)

                printE()

    def publish(self,retList=[],addon_id=''):
            printD("retlist-lenkkk",len(retList))
            self.threadsCounter=self.threadsCounter+1
            
            for item in retList:
                item.update({"caddon_id":addon_id})
           
            printD('len(retList)',len(retList))
            self.retList.append((addon_id,retList))
            self.totalCount=self.totalCount+len(retList)
                

             
            
            #print "currlist",len(self.currList)
           
            if self.threadsCounter==self.threadsCount:
                
                
                self.threadsRunning=False

        

    def listResults(self,name,mainURL,image,page,extra,tag):
        datalist=extra.get("datalist",[])
        for cParams in datalist:
                
                name=cParams.get('name',"")
                url=cParams.get('url',"")
                mode=cParams.get('mode',"")
                image=cParams.get('image',"")
                metaData=cParams.get('metaData',{})
                try:self.addDir(name,url,mode,image,'',1,metaData=metaData,tag=mainURL)
                except:continue
            

    def run(self, cParams):
        
        name = cParams.get('name', '')
        url = cParams.get('url', '')
        mode = cParams.get('mode', None)
        image = cParams.get('image', '')
        page = cParams.get('page', 1)
        extra = cParams.get('extra', {})
        show = cParams.get('show', 'movies')
        tag = cParams.get('tag', ' ')
        desc = cParams.get('desc', ' ')
        if mode == None:
            print ''
            sterm = self.getsearchtext()
            self.searchAll("Search",sterm,page)

        elif mode==104:
            self.listResults(name,url,image,page,extra,tag)
    
        return self.endDir()

######################starting addon
def start(cParams={}):
    
    addon = searchall(cParams)
    
    return addon.run(cParams)


