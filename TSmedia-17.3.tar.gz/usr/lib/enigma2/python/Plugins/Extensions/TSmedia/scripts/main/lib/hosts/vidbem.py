# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/main/lib/hosts/vidbem.py
 
from iTools import printD, printE, CBaseAddonClass
self = CBaseAddonClass()
import requests
import re
Sgn = requests.Session()

def toStringCases(txt_result):
    sum_base = ''
    m3 = False
    if '.toString(' in txt_result:
        if '+(' in txt_result:
            m3 = True
            sum_base = '+' + self.getSM(txt_result, '.toString...(\\d+).')
            txt_pre_temp = self.getMM(txt_result, '..(\\d),(\\d+).')
            txt_temp = [ (n, b) for b, n in txt_pre_temp ]
        else:
            txt_temp = self.getSM(txt_result, '(\\d+)\\.0.\\w+.([^\\)]+).')
        for numero, base in txt_temp:
            code = toString(int(numero), eval(base + sum_base))
            if m3:
                txt_result = re.sub('"|\\+', '', txt_result.replace('(' + base + ',' + numero + ')', code))
            else:
                txt_result = re.sub("'|\\+", '', txt_result.replace(numero + '.0.toString(' + base + ')', code))

    return txt_result


def toString(number, base):
    string = '0123456789abcdefghijklmnopqrstuvwxyz'
    if number < base:
        return string[number]
    else:
        return toString(number // base, base) + string[number % base]


def decode(text):
    text = re.sub('\\s+|/\\*.*?\\*/', '', text)
    data = text.split('+(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)[\xef\xbe\x9fo\xef\xbe\x9f]')[1]
    chars = data.split('+(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)[\xef\xbe\x9f\xce\xb5\xef\xbe\x9f]+')[1:]
    txt = ''
    for char in chars:
        char = char.replace('(o\xef\xbe\x9f\xef\xbd\xb0\xef\xbe\x9fo)', 'u').replace('c', '0').replace("(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)['0']", 'c').replace('\xef\xbe\x9f\xce\x98\xef\xbe\x9f', '1').replace('!+[]', '1').replace('-~', '1+').replace('o', '3').replace('_', '3').replace('\xef\xbe\x9f\xef\xbd\xb0\xef\xbe\x9f', '4').replace('(+', '(')
        char = re.sub('\\((\\d)\\)', '\\1', char)
        c = ''
        subchar = ''
        for v in char:
            c += v
            try:
                x = c
                subchar += str(eval(x))
                c = ''
            except:
                pass

        if subchar != '':
            txt += subchar + '|'

    txt = txt[:-1].replace('+', '')
    txt_result = ''.join([ chr(int(n, 8)) for n in txt.split('|') ])
    return toStringCases(txt_result)


def get_video_url(url):
    Infos = ''
    video_urls = []
    url = url.replace('\r', '')
    data = Sgn.get(url).content
    rgx = '\xef\xbe\x9f\xcf\x89\xef\xbe\x9f\xef\xbe\x89(.+?)</script>'
    _dat = re.findall(rgx, data, re.S)
    if _dat:
        Infos = decode(_dat[0])
        film = re.findall('\\{file:"(.+?)"', Infos)
        if film:
            print film[0]
            w = ('Cool_* vidbem', film[0])
            video_urls.append(w)
        else:
            w = ('Ooops_* vidbem', 'http://error')
            video_urls.append(w)
    else:
        w = ('Ooops_* vidbem', 'http://error')
        video_urls.append(w)
    return video_urls
