import requests,re
St=requests.Session()
def get_video_url(url):
    Mylist = []
    _r = St.get(url).content
    rgx = '''<input type="hidden" name="id" value="(.+?)">'''
    _id = re.findall(rgx,_r)
    if _id:_id=_id[0]
    else:_id = re.findall("video_id: '(.+?)'",_r)[0]
    prm={
	"op": "download2",
	"id": _id,
	"rand": "",
	"referer": "",
	"method_free": "",
	"method_premium": "",
	"adblock_detected": "1"}
    data = St.post(url,data=prm).content
    tmx = '<a href="(.+?)"><button class="lastbtn"><span>Free Download</span></button></a>'
    Download = re.findall(tmx,data)
    if Download:
        w=('Cool_youdbox',Download[0])
        Mylist.append(w)
    else:
        w=('Ooops_youdbox','http://Error')
        Mylist.append(w)
    return Mylist
if __name__=='__main__':
    url0='https://youdbox.com/embed-ozxm197cqjbu.html'
    print get_video_url(url0)
