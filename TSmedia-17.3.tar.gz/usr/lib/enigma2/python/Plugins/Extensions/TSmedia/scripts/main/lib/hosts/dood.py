import requests,re,js2py,time
St = requests.Session()
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
hdr={'Host': 'dood.so',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
'Accept': '*/*',
'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
'Accept-Encoding': 'gzip, deflate',
'X-Requested-With': 'XMLHttpRequest',
'Connection': 'keep-alive',
'Referer': 'https://dood.so/e/y50ia4vz9f15',
'TE': 'Trailers'}
def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""
def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    _id_vid = page_url.split('/')[-1]
    video_urls,data,_data = [],'',''
    host = "https://dood.so"
    page_url = 'https://dood.so/e/'+str(_id_vid)
    hdr.update({'Referer': page_url})
    try:data = St.get(page_url,verify=False).content
    except:data=''
    if data!='':
        label = find_single_match(data, 'type:\s*"video/([^"]+)"')
        js_code = find_single_match(data, ("(function makePlay.*?;})"))
        js_code = re.sub(r"\+Date.now\(\)", '', js_code)
        js = js2py.eval_js(js_code)
        makeplay = js() + str(int(time.time()*1000))
        base_url = find_single_match(data, r"\$.get\('(/pass[^']+)'")
        urlo = host+base_url
        try:_data = St.get(urlo,headers=hdr,verify=False).content
        except:_data=''
        if _data!='':
            data = re.sub(r'\s+', '', _data)
            url = data + makeplay + "#Referer=%s" % page_url
            video_urls.append(('Cool_dood',url))
        else:video_urls.append(('Ooops_dood','http://Error'))
    else:video_urls.append(('Ooops_dood','http://Error'))
    return video_urls
if __name__=='__main__':
    url0='https://dood.so/e/y50ia4vz9f15'
    print get_video_url(url0)
