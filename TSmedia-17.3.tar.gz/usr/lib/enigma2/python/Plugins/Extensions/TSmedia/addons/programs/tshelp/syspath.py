import os,sys,json,ast,urllib
print "sys.argv",sys.argv[2]

def addscripts():

        scriptsPath ='/usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts'
                   
             
        for name in os.listdir(scriptsPath):
                       if not os.path.isfile(name):
                          pacPath=os.path.join(scriptsPath,name)
                          sys.path.append(pacPath+"/lib")
                          for subname in os.listdir(pacPath+"/lib"):
                              if not os.path.isfile(subname):
                                  sys.path.append(pacPath+"/lib"+"/"+subname)
addscripts()    
from iTools import printD,printE
try:

        
        paramFile="/tmp/TSmedia/params.json"
        with open(paramFile) as outputFile:
            cParams = json.load(outputFile)
        print "Input params-syspath",cParams
       
        
        try:
          printD("starting process-syspath")      
          from default import start
          datalist=start(cParams)
          printD("datalist-syspath",datalist)
          dataFile='/tmp/TSmedia/data'
          if os.path.exists(dataFile):
                  os.remove(dataFile)
          with open(dataFile, 'w') as outfile:
            json.dump(datalist, outfile)
        except Exception as error:
              printE()
              print "Error:", str(error)
except Exception as error:
        
        print "error",str(error)
        printE()
