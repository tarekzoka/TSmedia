import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
import requests,re
St=requests.Session()
def get_video_url(url):
    Mylist = []
    stream_url = []
    data = St.get(url,verify=False)
    regx='''innerHTML'\]='(.+?)';'''
    stream_url=re.findall(regx,data.content, re.M|re.I)[0]
    if stream_url:
        if stream_url.startswith('//'):stream_url='https:'+stream_url+'&stream=1'
        ll = requests.head(stream_url,allow_redirects=False).headers
        ll = ll['Location']
        w=('Cool_streamtape',ll)
        Mylist.append(w)
    else:
        w=('Ooops_streamtape','http://Error')
        Mylist.append(w)
    return Mylist
if __name__=='__main__':
   url0='https://streamtape.com/e/d76X2vvdMZSk6lP/Z.2019.720p.BluRay.Cima2u.Co.mp4'
   print get_video_url(url0)