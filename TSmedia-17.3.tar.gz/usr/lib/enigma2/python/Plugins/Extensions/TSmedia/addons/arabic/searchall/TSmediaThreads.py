# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/screens/TSmediaThreads.py
from twisted.web import client
from twisted.internet import reactor
import os, requests, urllib2, re, shutil
from Plugins.Extensions.TSmedia.lib.pltools import logdata, trace_error, dellog, downloadImage, cfdownloadImage
from threading import Thread

class dataThread(Thread):

    def __init__(self, getData, cParams={}, callBack = None):
        Thread.__init__(self)
        logdata('dataThtead initiated...', '')
        self.getData = getData
        self.cParams = cParams
        self.callBack = callBack
        self.dataThread_showData = True
        self.addon_id=cParams.get("caddon_id","")

    def run(self):
        logdata('dataThtead running...', '')
        datalist = []
        try:
            datalist = self.getData(self.cParams)
        except Exception as error:
            trace_error()

        logdata('dataThtead finished...Puplishing data-data length', len(datalist))
        reactor.callFromThread(self.callBack, datalist,self.addon_id)

    def stop(self):
        self.dataThread_showData = False


class downloadImageThread(Thread):

    def __init__(self, webfile, localfile, images_cachepath, imageIndex, callBack = None):
        Thread.__init__(self)
        self.webfile = webfile
        self.imageIndex = imageIndex
        self.images_cachepath = images_cachepath
        self.localfile = localfile
        self.callBack = callBack

    def run(self):
        try:
            localfile = downloadImage(url=self.webfile, localFile=self.localfile)
        except:
            trace_error()

        reactor.callFromThread(self.callBack, self.localfile, self.webfile, self.imageIndex)

    def stop(self):
        self.dataThread_exit = True


class cfdownloadImageThread(Thread):

    def __init__(self, webfile, localfile, images_cachepath, imageIndex, callBack = None):
        Thread.__init__(self)
        self.webfile = webfile
        self.imageIndex = imageIndex
        self.images_cachepath = images_cachepath
        self.localfile = localfile
        self.callBack = callBack

    def run(self):
        try:
            localfile = cfdownloadImage(self.webfile, self.images_cachepath, self.localfile)
        except:
            trace_error()

        reactor.callFromThread(self.callBack, self.localfile, self.webfile, self.imageIndex)

    def stop(self):
        self.dataThread_exit = True


class downloadImageTwisted:

    def __init__(self, localfile, webfile, imageIndex, callBackSuccess = None, callBackError = None):
        self.webfile = webfile
        self.imageIndex = imageIndex
        self.localfile = localfile
        self.callBackSuccess = callBackSuccess
        self.callBackError = callBackError

    def start(self):
        try:
            logdata('self.webfile-twisted', self.webfile)
            client.downloadPage(self.webfile, self.localfile, timeout=3).addCallback(self.callBackOnSucces).addErrback(self.callBackOnError, self.imageIndex)
        except:
            trace_error()

    def callBackOnSucces(self, data):
        logdata('twisted-data-success', data)
        self.callBackSuccess(data, self.imageIndex, self.localfile)

    def callBackOnError(self, data):
        logdata('twisted-data-error', data)
        self.callBackError(data, self.imageIndex)

    def stop(self):
        self.dataTwisted_exit = True
