#!/usr/bin/env python3
# adapted from code by @stephenhouser on github
# https://gist.github.com/stephenhouser/c5e2b921c3770ed47eb3b75efbc94799
from bs4 import BeautifulSoup
import requests
import re
import sys
import os 
 
import json,urllib2
#!/usr/bin/env python3
from bs4 import BeautifulSoup
import requests
import re
import sys
import os
 
import json,urllib



def get_soup(url,header):
    from bs4 import BeautifulSoup    
    return BeautifulSoup(urllib2.urlopen(urllib2.Request(url,headers=header)),'html.parser')
def getfilename(image):

    
    return   image.split('/')[-1].split('.')[0]


    
def getimages(query = 'dahab'):

    query= query.split()
    query='+'.join(query)
    url="http://www.bing.com/images/search?q=" + query + "&FORM=HDRSC2"

    #add the directory for your image here
    DIR="Pictures"
    header={'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}
    soup = get_soup(url,header)

    ActualImages=[]# contains the link for Large original images, type of  image
    for a in soup.find_all("a",{"class":"iusc"}):
        #print a
        #mad = json.loads(a["mad"])
        #turl = mad["turl"]
        m = json.loads(a["m"])
        murl = m["murl"]
        
        image_name = getfilename(murl)
        

        ActualImages.append((image_name,murl, murl))

    print("there are total" , len(ActualImages),"images")

    return ActualImages

    ##print images
    for i, (image_name, turl, murl) in enumerate(ActualImages):
        try:
            #req = urllib2.Request(turl, headers={'User-Agent' : header})
            #raw_img = urllib2.urlopen(req).read()
           #raw_img = urllib.request.urlopen(turl).read()

            
            print "murl",murl
            
        except Exception as e:
            print("could not load : " + image_name)
            print(e) 




getimages()
